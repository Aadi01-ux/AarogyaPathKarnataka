# ============================================================
# Aarogya Path Karnataka — MySQL Fix (Run as Administrator)
# ============================================================

$mysql   = "C:\Program Files\MySQL\MySQL Server 8.0\bin\mysql.exe"
$mysqld  = "C:\Program Files\MySQL\MySQL Server 8.0\bin\mysqld.exe"
$dataDir = "C:\Program Files\MySQL\MySQL Server 8.0\data"
$newPass = "AarogyaPath@2024"
$initSql = "C:\Users\HP\Desktop\AarogyaPathKarnataka\reset_root.sql"

Write-Host "STEP 1 - Stopping MySQL service..." -ForegroundColor Cyan
net stop MySQL80 2>&1 | Out-Null
Start-Sleep -Seconds 2

Write-Host "STEP 2 - Writing SQL reset file..." -ForegroundColor Cyan
$line1 = "ALTER USER 'root'@'localhost' IDENTIFIED BY '" + $newPass + "';"
$line2 = "FLUSH PRIVILEGES;"
$line3 = "SHUTDOWN;"
($line1, $line2, $line3) -join "`r`n" | Set-Content -Path $initSql -Encoding ASCII
Write-Host "        Written to $initSql" -ForegroundColor Green

Write-Host "STEP 3 - Running mysqld with init-file to reset password..." -ForegroundColor Cyan
$p = Start-Process -FilePath $mysqld -ArgumentList ('--init-file="' + $initSql + '" --datadir="' + $dataDir + '"') -PassThru -NoNewWindow
Write-Host "        mysqld PID $($p.Id) started. Waiting 15 seconds..." -ForegroundColor Yellow
Start-Sleep -Seconds 15
if (-not $p.HasExited) {
    Write-Host "        mysqld still running - stopping it now" -ForegroundColor Red
    Stop-Process -Id $p.Id -Force -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 2
} else {
    Write-Host "        mysqld finished cleanly." -ForegroundColor Green
}

Write-Host "STEP 4 - Starting MySQL service..." -ForegroundColor Cyan
net start MySQL80 2>&1 | Out-Null
Start-Sleep -Seconds 3
$svc = Get-Service MySQL80
Write-Host "        Service status: $($svc.Status)" -ForegroundColor Green

Write-Host "STEP 5 - Testing connection with new password..." -ForegroundColor Cyan
$out = & $mysql -u root ("-p" + $newPass) -e "SELECT VERSION() AS mysql_version;" 2>&1
Write-Host "        $out"

Write-Host "STEP 6 - Creating aarogya_path database..." -ForegroundColor Cyan
$out2 = & $mysql -u root ("-p" + $newPass) -e "CREATE DATABASE IF NOT EXISTS aarogya_path CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;" 2>&1
Write-Host "        $out2"

Write-Host ""
Write-Host "======================================" -ForegroundColor Cyan
Write-Host " Root password : AarogyaPath@2024" -ForegroundColor White
Write-Host " Database      : aarogya_path" -ForegroundColor White
Write-Host "======================================" -ForegroundColor Cyan
