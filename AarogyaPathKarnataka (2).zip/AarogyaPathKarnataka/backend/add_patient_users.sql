-- add_patient_users.sql
-- Migration: add the patient_users table for the patient-facing portal.
--
-- Run AFTER the existing tables are already created (create_tables.sql).
-- Safe to run multiple times — uses IF NOT EXISTS.
--
-- Usage:
--   mysql -u your_username -p aarogya_path < backend/add_patient_users.sql
--
-- Or paste into MySQL Workbench / phpMyAdmin after selecting aarogya_path.

-- ---------------------------------------------------------------------------
-- 8. patient_users — login credentials for the patient portal
--    One account per patient (patient_id UNIQUE).
--    Linked to the existing patients table — that table is NOT modified.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS patient_users (
    id            INT          NOT NULL AUTO_INCREMENT,
    patient_id    INT          NOT NULL,               -- FK → patients.id
    username      VARCHAR(100) NOT NULL,               -- patient-chosen username
    password_hash VARCHAR(255) NOT NULL,               -- bcrypt hash, never plain text
    created_at    DATETIME     DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_patient_id (patient_id),             -- one account per patient
    UNIQUE KEY uq_username   (username),
    CONSTRAINT fk_patientuser_patient
        FOREIGN KEY (patient_id) REFERENCES patients (id)
        ON DELETE CASCADE
);
