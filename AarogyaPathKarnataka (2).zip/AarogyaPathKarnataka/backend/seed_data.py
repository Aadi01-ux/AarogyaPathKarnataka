"""
seed_data.py — Populate the database with synthetic data for demos and testing.

Run from the workspace root or backend/ directory:
    python backend/seed_data.py

This script is IDEMPOTENT — it checks whether data already exists before
inserting. Running it twice will not create duplicates.

Synthetic data only — no real patient or staff information.
"""

import sys
import os
from datetime import datetime, timedelta

# Ensure backend/ is on the Python path
sys.path.insert(0, os.path.dirname(__file__))

import bcrypt
from config import get_db_session
from models.db_models import StaffUser, Patient, Referral, Appointment, Task


def hash_password(plain: str) -> str:
    """Hash a plain-text password using bcrypt and return the string digest."""
    return bcrypt.hashpw(plain.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")


def main():
    """
    Insert seed data into the database.
    Skips everything if staff users already exist (idempotency check).
    """
    db = get_db_session()

    try:
        # ----------------------------------------------------------------
        # Idempotency check — if staff users already exist, stop here
        # ----------------------------------------------------------------
        existing_staff = db.query(StaffUser).count()
        if existing_staff > 0:
            print(f"[SKIP] Seed data already present ({existing_staff} staff users found). Nothing inserted.")
            return

        print("Seeding database with synthetic data...")

        # ----------------------------------------------------------------
        # 1. Staff Users (2 total)
        # ----------------------------------------------------------------
        staff_users = [
            StaffUser(
                username="admin",
                password_hash=hash_password("Admin@1234"),
                full_name="Admin User (Synthetic)",
                role="admin"
            ),
            StaffUser(
                username="coordinator",
                password_hash=hash_password("Coord@1234"),
                full_name="Priya Sharma (Synthetic)",
                role="coordinator"
            ),
        ]
        db.add_all(staff_users)
        db.flush()   # assign IDs without committing
        print(f"  [OK] Inserted {len(staff_users)} staff users")

        # ----------------------------------------------------------------
        # 2. Patients (10 total — Karnataka names and villages)
        # ----------------------------------------------------------------
        patients_data = [
            # (name, village, phone, language_pref, consent_on_file)
            ("Ravi Kumar",       "Hesaraghatta",    "+91-9876500001", "en", True),
            ("Lakshmi Devi",     "Doddaballapur",   "+91-9876500002", "kn", True),
            ("Suresh Nayak",     "Channapatna",     "+91-9876500003", "en", True),
            ("Meena Reddy",      "Ramanagara",      "+91-9876500004", "kn", True),
            ("Gopal Rao",        "Tumkur",          "+91-9876500005", "en", True),
            ("Savitha Gowda",    "Kolar",           "+91-9876500006", "kn", True),
            ("Manjunath Patil",  "Mandya",          "+91-9876500007", "en", True),
            ("Anitha Bai",       "Hassan",          "+91-9876500008", "kn", True),
            ("Venkatesh Murthy", "Mysuru",          "+91-9876500009", "en", False),
            ("Kavitha Naik",     "Shivamogga",      "+91-9876500010", "kn", False),
        ]
        patients = []
        for name, village, phone, lang, consent in patients_data:
            p = Patient(
                name=name,
                village=village,
                phone=phone,
                language_pref=lang,
                consent_on_file=consent
            )
            patients.append(p)
        db.add_all(patients)
        db.flush()
        print(f"  [OK] Inserted {len(patients)} patients")

        # ----------------------------------------------------------------
        # 3. Referrals (15 total — mix of all 4 statuses)
        #    pending×5, confirmed×4, completed×4, unconfirmed×2
        # ----------------------------------------------------------------
        # Helper: round-robin over patients[0..9]
        def patient_id(idx):
            return patients[idx % len(patients)].id

        specialists = [
            "Cardiologist",
            "Ophthalmologist",
            "Orthopedic Surgeon",
            "Neurologist",
            "Dermatologist",
            "General Surgeon",
        ]
        urgencies = ["high", "medium", "low", "medium", "high",
                     "low",  "high",   "medium", "low",  "high",
                     "medium", "low", "high",   "medium", "low"]
        statuses  = (
            ["pending"]     * 5 +
            ["confirmed"]   * 4 +
            ["completed"]   * 4 +
            ["unconfirmed"] * 2
        )
        docs = [
            "Dr. Test Physician (Synthetic)",
            "Dr. Sample Doctor (Synthetic)",
        ]

        referrals = []
        base_time = datetime.utcnow() - timedelta(days=30)
        for i in range(15):
            r = Referral(
                patient_id=patient_id(i),
                referring_doctor=docs[i % 2],
                specialist_needed=specialists[i % len(specialists)],
                urgency=urgencies[i],
                status=statuses[i],
                raw_document_text=(
                    f"Referral document for {specialists[i % len(specialists)]}. "
                    f"Patient presents with symptoms requiring specialist evaluation. "
                    f"Urgency: {urgencies[i]}. (Synthetic data only)"
                ),
                extracted_data={
                    "referring_doctor":  docs[i % 2],
                    "specialist_needed": specialists[i % len(specialists)],
                    "urgency":           urgencies[i],
                    "notes":             "Extracted by seed script (synthetic)."
                },
                created_at=base_time + timedelta(days=i * 2)
            )
            referrals.append(r)
        db.add_all(referrals)
        db.flush()
        print(f"  [OK] Inserted {len(referrals)} referrals")

        # ----------------------------------------------------------------
        # 4. Appointments and Tasks — at least 2 per referral
        # ----------------------------------------------------------------
        appt_types = ["specialist_visit", "lab_test", "follow_up"]
        locations  = ["District Hospital (Synthetic)", "Govt Lab (Synthetic)"]
        appointments = []
        tasks        = []

        for idx, ref in enumerate(referrals):
            # Appointment 1
            appt1 = Appointment(
                referral_id=ref.id,
                type=appt_types[idx % 3],
                location=locations[idx % 2],
                scheduled_at=ref.created_at + timedelta(days=7),
                status="pending" if ref.status in ("pending", "unconfirmed") else "completed"
            )
            # Appointment 2
            appt2 = Appointment(
                referral_id=ref.id,
                type="follow_up",
                location=locations[(idx + 1) % 2],
                scheduled_at=ref.created_at + timedelta(days=14),
                status="pending" if ref.status in ("pending", "unconfirmed") else "completed"
            )
            appointments.extend([appt1, appt2])

            # Task 1
            task1 = Task(
                referral_id=ref.id,
                description=f"Collect medical records for {ref.specialist_needed} referral (Synthetic).",
                completed=(ref.status == "completed"),
                created_at=ref.created_at
            )
            # Task 2
            task2 = Task(
                referral_id=ref.id,
                description=f"Confirm insurance and transport for patient appointment (Synthetic).",
                completed=(ref.status in ("completed", "confirmed")),
                created_at=ref.created_at + timedelta(days=1)
            )
            tasks.extend([task1, task2])

        db.add_all(appointments)
        db.add_all(tasks)
        db.flush()
        print(f"  [OK] Inserted {len(appointments)} appointments")
        print(f"  [OK] Inserted {len(tasks)} tasks")

        # Commit everything at once
        db.commit()
        print("\n[DONE] Seed data committed successfully.")
        print(f"       Staff: {len(staff_users)}, Patients: {len(patients)}, "
              f"Referrals: {len(referrals)}, "
              f"Appointments: {len(appointments)}, Tasks: {len(tasks)}")

    except Exception as e:
        db.rollback()
        print(f"\n[ERROR] Seed failed — rolled back. Details: {e}")
        raise
    finally:
        db.close()


if __name__ == "__main__":
    main()
