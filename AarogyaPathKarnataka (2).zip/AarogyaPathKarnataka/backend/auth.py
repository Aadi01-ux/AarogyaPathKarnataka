"""
auth.py — Session management and auth decorators for both portals.

Provides:
  - login_required(f):         staff portal — checks session["staff_user_id"]
  - patient_login_required(f): patient portal — checks session["patient_user_id"]

Uses Flask's built-in session object (signed with SECRET_KEY).
"""

from functools import wraps
from flask import session, jsonify


def login_required(f):
    """
    Decorator for protected routes.

    How it works:
      1. Before the route function runs, check if 'staff_user_id' is in
         the Flask session (set during login).
      2. If the key is missing, the user is not authenticated — return a
         JSON 401 response immediately.
      3. If the key exists, call the original route function normally.

    Usage:
        @api_bp.route("/api/dashboard")
        @login_required
        def get_dashboard():
            ...
    """
    @wraps(f)
    def decorated_function(*args, **kwargs):
        # Check for valid session
        if "staff_user_id" not in session:
            return jsonify({
                "success": False,
                "error": "Unauthorized. Please log in."
            }), 401
        # Session valid — proceed to the route
        return f(*args, **kwargs)
    return decorated_function


def patient_login_required(f):
    """
    Decorator for patient-portal protected routes.

    Checks that 'patient_user_id' exists in the Flask session (set during
    patient login). Returns HTTP 401 if the patient is not authenticated.

    Usage:
        @patient_bp.route("/api/patient/referrals")
        @patient_login_required
        def get_my_referrals():
            ...
    """
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if "patient_user_id" not in session:
            return jsonify({
                "success": False,
                "error": "Unauthorized. Please log in to the patient portal."
            }), 401
        return f(*args, **kwargs)
    return decorated_function
