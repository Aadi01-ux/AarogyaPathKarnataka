"""
app.py — Flask application entry point for Aarogya Path Karnataka.

Starts the server, registers blueprints, and provides the /api/health endpoint.
Run with:  python backend/app.py
"""

import os
import sys

# Force SQLAlchemy to use its pure-Python implementation.
# Required on systems where compiled C extensions are blocked by policy.
os.environ.setdefault("SQLALCHEMY_DISABLE_CEXT", "1")

# Add the backend directory to Python's search path so imports like
# 'from config import ...' work when running from the project root.
sys.path.insert(0, os.path.dirname(__file__))

from flask import Flask, jsonify, send_from_directory
from flask_cors import CORS

import config  # loads .env via python-dotenv

# Import blueprints (each blueprint groups related routes)
from routes.api_routes          import api_bp
from routes.auth_routes         import auth_bp
from routes.patient_auth_routes import patient_auth_bp
from routes.patient_routes      import patient_bp

# ---------------------------------------------------------------------------
# Create Flask app
# ---------------------------------------------------------------------------
app = Flask(
    __name__,
    # Disable Flask's automatic static serving — we handle it explicitly below
    # so that named routes like /patient-login take priority over the catch-all.
    static_folder=None
)

# Frontend directory path used by all page-serving routes
_FRONTEND_DIR = os.path.join(os.path.dirname(__file__), "..", "frontend")

# Secret key is required for session cookies
app.config["SECRET_KEY"] = config.SECRET_KEY

# Preserve Unicode (Kannada script) in JSON responses — works Flask 2.2+
app.config["JSON_ENSURE_ASCII"] = False
try:
    app.json.ensure_ascii = False   # Flask 2.3+
except AttributeError:
    pass

# Enable Cross-Origin Resource Sharing so the frontend (possibly on a
# different port during development) can call the backend API
CORS(app, supports_credentials=True)

# ---------------------------------------------------------------------------
# Register blueprints
# ---------------------------------------------------------------------------
app.register_blueprint(api_bp)
app.register_blueprint(auth_bp)
app.register_blueprint(patient_auth_bp)
app.register_blueprint(patient_bp)

# ---------------------------------------------------------------------------
# Health check endpoint — confirm the server is running
# ---------------------------------------------------------------------------
@app.route("/api/health", methods=["GET"])
def health():
    """Returns a simple status response so we can verify the server is up."""
    return jsonify({
        "success": True,
        "status": "ok",
        "project": "Aarogya Path Karnataka"
    })

# ---------------------------------------------------------------------------
# Serve frontend
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# Named HTML page routes — must be registered BEFORE the static catch-all
# ---------------------------------------------------------------------------
@app.route("/")
def index():
    """Serve the main frontend page."""
    return send_from_directory(_FRONTEND_DIR, "index.html")

@app.route("/login")
def login_page():
    """Serve the staff login page."""
    return send_from_directory(_FRONTEND_DIR, "login.html")

@app.route("/patient-login")
def patient_login_page():
    """Serve the patient login / registration page."""
    return send_from_directory(_FRONTEND_DIR, "patient-login.html")

@app.route("/patient-portal")
def patient_portal_page():
    """Serve the patient-facing portal page."""
    return send_from_directory(_FRONTEND_DIR, "patient-portal.html")

# ---------------------------------------------------------------------------
# Static file catch-all — CSS, JS, images etc.
# Must come AFTER named routes so /patient-login is not swallowed by this.
# ---------------------------------------------------------------------------
@app.route("/<path:filename>")
def static_files(filename):
    """Serve any other static file (css/, js/, images/ …) from the frontend dir."""
    return send_from_directory(_FRONTEND_DIR, filename)

# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    print("Starting Aarogya Path Karnataka backend...")
    print("Health check: http://127.0.0.1:5000/api/health")
    # use_reloader=False prevents the watchdog from restarting on bcrypt import
    app.run(debug=True, host="0.0.0.0", port=5000, use_reloader=False)
