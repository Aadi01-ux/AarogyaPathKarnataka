"""
watsonx_client.py — Shared IBM Granite LLM client.

One function: generate(prompt) -> str
Handles IAM token fetching and caching.
All agents call this module — never call the API directly from agent files.
"""

import os
import time
import requests
import sys

# Ensure backend/ is on the path
sys.path.insert(0, os.path.dirname(__file__))
from config import WATSONX_API_KEY, WATSONX_PROJECT_ID, WATSONX_URL, WATSONX_MODEL_ID

# ---------------------------------------------------------------------------
# Token cache (module-level, persists for the life of the process)
# ---------------------------------------------------------------------------
_iam_token = None
_token_expires_at = 0

# Placeholder sentinel — if the key is literally this value, don't call IBM
_PLACEHOLDER_KEY = "your_watsonx_api_key_here"


def _is_placeholder_key():
    """Return True if the API key looks like a placeholder (not a real key)."""
    if not WATSONX_API_KEY:
        return True
    if WATSONX_API_KEY == _PLACEHOLDER_KEY:
        return True
    return False


def _get_iam_token():
    """
    Fetch a fresh IAM token from IBM Cloud. Cache it until 5 min before expiry.
    Raises RuntimeError if the API key is a placeholder.
    """
    global _iam_token, _token_expires_at

    # Return cached token if still valid
    if _iam_token and time.time() < _token_expires_at:
        return _iam_token

    resp = requests.post(
        "https://iam.cloud.ibm.com/identity/token",
        data={
            "grant_type": "urn:ibm:params:oauth:grant-type:apikey",
            "apikey": WATSONX_API_KEY
        },
        headers={"Content-Type": "application/x-www-form-urlencoded"},
        timeout=30
    )
    resp.raise_for_status()
    data = resp.json()
    _iam_token = data["access_token"]
    # Refresh 5 minutes before the token actually expires
    _token_expires_at = time.time() + data.get("expires_in", 3600) - 300
    return _iam_token


def generate(prompt: str, max_new_tokens: int = 500) -> str:
    """
    Send a prompt to IBM Granite and return the generated text.

    Args:
        prompt:         The text prompt to send to the model.
        max_new_tokens: Maximum number of tokens to generate (default 500).

    Returns:
        The model's generated text as a plain string.
        If anything goes wrong, returns an "ERROR: ..." string so agents
        can degrade gracefully without crashing.
    """
    # --- Guard: placeholder API key ---
    if _is_placeholder_key():
        return (
            "ERROR: IBM watsonx API key is not configured. "
            "Please set WATSONX_API_KEY in your .env file to enable AI features. "
            "All other (non-AI) features remain fully functional."
        )

    try:
        token = _get_iam_token()

        # Build the watsonx.ai REST endpoint URL
        url = f"{WATSONX_URL}/ml/v1/text/generation?version=2023-05-29"

        payload = {
            "model_id": WATSONX_MODEL_ID,
            "input": prompt,
            "parameters": {
                "decoding_method": "greedy",
                "max_new_tokens": max_new_tokens,
                "stop_sequences": ["<|endoftext|>"]
            },
            "project_id": WATSONX_PROJECT_ID
        }

        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json"
        }

        resp = requests.post(url, json=payload, headers=headers, timeout=60)
        resp.raise_for_status()

        # Extract generated text from the response
        results = resp.json().get("results", [])
        if results:
            return results[0].get("generated_text", "").strip()

        return "ERROR: No results returned from Granite."

    except Exception as e:
        # Never let an AI failure crash the application
        return f"ERROR: {str(e)}"
