import sys, os, requests, time
sys.path.insert(0, os.path.dirname(__file__))
from config import WATSONX_API_KEY, WATSONX_PROJECT_ID, WATSONX_URL, WATSONX_MODEL_ID

# Get IAM token
resp = requests.post(
    "https://iam.cloud.ibm.com/identity/token",
    data={"grant_type": "urn:ibm:params:oauth:grant-type:apikey", "apikey": WATSONX_API_KEY},
    headers={"Content-Type": "application/x-www-form-urlencoded"},
    timeout=30
)
token = resp.json()["access_token"]
print("Token acquired.")

doc = "Dear Specialist, I am referring Mr. Suresh Nayak, 38-year-old male from Channapatna. He complains of persistent lower back pain. Please evaluate. Regards, Dr. Test Physician (Synthetic)"

# Try multiple prompt styles and report raw API response
prompts = {
    "chat_template": (
        "<|system|>\nYou are a JSON extractor. Return only valid JSON.\n"
        "<|user|>\nExtract referring_doctor, specialist_needed, urgency (high/medium/low), notes "
        "from this referral. Return only the JSON object.\nDocument: " + doc + "\n<|assistant|>\n"
    ),
    "simple_colon": (
        "Extract referral info as JSON with fields: referring_doctor, specialist_needed, urgency (high/medium/low), notes.\n"
        "Document: " + doc + "\nJSON:"
    ),
    "instruction_format": (
        "### Instruction:\nExtract referring_doctor, specialist_needed, urgency, notes from the document as JSON.\n"
        "### Document:\n" + doc + "\n### Response:\n"
    ),
}

url = f"{WATSONX_URL}/ml/v1/text/generation?version=2023-05-29"
headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}

for name, prompt in prompts.items():
    payload = {
        "model_id": WATSONX_MODEL_ID,
        "input": prompt,
        "parameters": {"decoding_method": "greedy", "max_new_tokens": 300},
        "project_id": WATSONX_PROJECT_ID
    }
    r = requests.post(url, json=payload, headers=headers, timeout=60)
    result = r.json()
    generated = result.get("results", [{}])[0].get("generated_text", "")
    stop_reason = result.get("results", [{}])[0].get("stop_reason", "")
    print(f"\n=== {name} ===")
    print(f"Stop reason: {stop_reason}")
    print(f"Generated:   {repr(generated)}")
