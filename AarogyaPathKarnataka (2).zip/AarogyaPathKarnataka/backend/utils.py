"""
utils.py — Shared utility functions used by multiple agents.

Agents import from here — never call each other directly.

Functions:
  translate(text, target_language)       — translate using IBM Granite
  parse_json_from_response(response)     — extract JSON from Granite output
"""

import re
import json
import sys
import os

# Ensure backend/ is on the path when imported from agents/
sys.path.insert(0, os.path.dirname(__file__))

from watsonx_client import generate


def translate(text: str, target_language: str) -> str:
    """
    Translate text to 'en' (English) or 'kn' (Kannada) using IBM Granite.

    Args:
        text:            The text to translate.
        target_language: 'en' for English, 'kn' for Kannada.

    Returns:
        Translated text as a string, or an ERROR: ... string on failure.

    Raises:
        ValueError: if target_language is not 'en' or 'kn'.
    """
    if target_language not in ("en", "kn"):
        raise ValueError(
            f"Unsupported language: {target_language}. Use 'en' or 'kn'."
        )

    lang_name = "English" if target_language == "en" else "Kannada"

    # Keep the prompt simple — no safety disclaimers that cause the model to refuse
    prompt = (
        "<|system|>\n"
        f"You are a helpful {lang_name} language translator.\n"
        "<|user|>\n"
        f"Translate the following sentence to {lang_name}. "
        f"Return only the translated sentence, nothing else.\n\n"
        f"Sentence: {text}\n"
        "<|assistant|>\n"
    )

    result = generate(prompt, max_new_tokens=300)
    if not result or result.startswith("ERROR"):
        # Return a human-readable fallback; callers check startswith("[Translation")
        return (
            f"[Translation unavailable — IBM Granite not configured. "
            f"Please set WATSONX_API_KEY in your .env file.]"
        )
    return result


def parse_json_from_response(response: str):
    """
    Try to extract and parse a JSON object or array from a Granite response
    that may be wrapped in prose.

    Tries three strategies in order:
      1. Direct JSON parse of the entire response
      2. Extract the first {...} block
      3. Extract the first [...] block

    Args:
        response: raw string returned by watsonx_client.generate()

    Returns:
        Parsed Python object (dict or list), or None if all strategies fail.
    """
    # Strategy 1: entire response is valid JSON
    try:
        return json.loads(response)
    except Exception:
        pass

    # Strategy 2: find a JSON object anywhere in the text
    m = re.search(r'\{.*\}', response, re.DOTALL)
    if m:
        try:
            return json.loads(m.group())
        except Exception:
            pass

    # Strategy 3: find a JSON array anywhere in the text
    m = re.search(r'\[.*\]', response, re.DOTALL)
    if m:
        try:
            return json.loads(m.group())
        except Exception:
            pass

    # All strategies exhausted
    return None
