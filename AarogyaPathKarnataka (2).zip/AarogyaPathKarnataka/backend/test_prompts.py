import sys, os
sys.path.insert(0, os.path.dirname(__file__))
from watsonx_client import generate

doc = "Dear Specialist, I am referring Mrs. Lakshmi Devi, a 52-year-old female. She has severe eye pain and reduced vision. Please see her urgently for ophthalmic evaluation. Regards, Dr. Test Physician (Synthetic)"

# Test 1: simple prompt (no chat template)
print("=== TEST 1: Simple prompt ===")
p1 = (
    "Extract referral info and return ONLY JSON with keys: "
    "referring_doctor, specialist_needed, urgency (high/medium/low), notes.\n\n"
    "Document: " + doc + "\n\n"
    "JSON:"
)
r1 = generate(p1, max_new_tokens=200)
print("Response:", repr(r1))
print()

# Test 2: chat template
print("=== TEST 2: Chat template ===")
p2 = (
    "<|system|>\nYou are a JSON extractor. Return only valid JSON.\n"
    "<|user|>\nExtract: referring_doctor, specialist_needed, urgency (high/medium/low), notes from:\n"
    + doc + "\nReturn only JSON.\n<|assistant|>\n"
)
r2 = generate(p2, max_new_tokens=200)
print("Response:", repr(r2))
print()

# Test 3: minimal instruction
print("=== TEST 3: Minimal ===")
p3 = "Return JSON only. Fields: referring_doctor, specialist_needed, urgency, notes.\nDocument: " + doc
r3 = generate(p3, max_new_tokens=200)
print("Response:", repr(r3))
