-- create_tables.sql
-- Run these statements in MySQL to create all tables for Aarogya Path Karnataka.
--
-- Usage:
--   mysql -u your_username -p aarogya_path < backend/create_tables.sql
--
-- Or paste into MySQL Workbench / phpMyAdmin.
-- Make sure the database already exists:
--   CREATE DATABASE IF NOT EXISTS aarogya_path;
--   USE aarogya_path;

-- ---------------------------------------------------------------------------
-- 1. staff_users — healthcare staff who can log in
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS staff_users (
    id            INT          NOT NULL AUTO_INCREMENT,
    username      VARCHAR(100) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,       -- bcrypt hash, never plain text
    full_name     VARCHAR(200) NOT NULL,
    role          VARCHAR(50)  NOT NULL,       -- 'admin' or 'coordinator'
    created_at    DATETIME     DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_username (username)
);

-- ---------------------------------------------------------------------------
-- 2. patients — synthetic patient records (no real data)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS patients (
    id              INT          NOT NULL AUTO_INCREMENT,
    name            VARCHAR(200) NOT NULL,
    village         VARCHAR(200),
    phone           VARCHAR(20),
    language_pref   VARCHAR(10)  DEFAULT 'en',   -- 'en' or 'kn'
    consent_on_file TINYINT(1)   DEFAULT 0,       -- 0 = no, 1 = yes
    created_at      DATETIME     DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
);

-- ---------------------------------------------------------------------------
-- 3. referrals — specialist referrals created from uploaded documents
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS referrals (
    id                INT          NOT NULL AUTO_INCREMENT,
    patient_id        INT          NOT NULL,
    referring_doctor  VARCHAR(200),
    specialist_needed VARCHAR(200),
    urgency           VARCHAR(20),              -- 'high', 'medium', 'low'
    status            VARCHAR(30)  DEFAULT 'pending',
    -- 'pending', 'confirmed', 'completed', 'unconfirmed'
    raw_document_text TEXT,                     -- original uploaded text
    extracted_data    JSON,                     -- fields parsed by IBM Granite
    created_at        DATETIME     DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    CONSTRAINT fk_referral_patient FOREIGN KEY (patient_id) REFERENCES patients (id)
);

-- ---------------------------------------------------------------------------
-- 4. appointments — scheduled visits, lab tests, follow-ups
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS appointments (
    id           INT          NOT NULL AUTO_INCREMENT,
    referral_id  INT          NOT NULL,
    type         VARCHAR(50),                   -- 'specialist_visit', 'lab_test', 'follow_up'
    location     VARCHAR(300),                  -- hospital or lab name
    scheduled_at DATETIME,
    status       VARCHAR(30)  DEFAULT 'pending', -- 'pending', 'completed', 'cancelled'
    PRIMARY KEY (id),
    CONSTRAINT fk_appointment_referral FOREIGN KEY (referral_id) REFERENCES referrals (id)
);

-- ---------------------------------------------------------------------------
-- 5. tasks — administrative tasks linked to a referral
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS tasks (
    id          INT       NOT NULL AUTO_INCREMENT,
    referral_id INT       NOT NULL,
    description TEXT      NOT NULL,
    completed   TINYINT(1) DEFAULT 0,           -- 0 = pending, 1 = done
    created_at  DATETIME   DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    CONSTRAINT fk_task_referral FOREIGN KEY (referral_id) REFERENCES referrals (id)
);

-- ---------------------------------------------------------------------------
-- 6. reminders — patient reminders (requires consent before sending)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS reminders (
    id            INT       NOT NULL AUTO_INCREMENT,
    referral_id   INT       NOT NULL,
    message_en    TEXT,                          -- English reminder text
    message_kn    TEXT,                          -- Kannada reminder text
    consent_given TINYINT(1) DEFAULT 0,          -- must be 1 before sending
    sent_at       DATETIME   DEFAULT NULL,       -- NULL until dispatched
    PRIMARY KEY (id),
    CONSTRAINT fk_reminder_referral FOREIGN KEY (referral_id) REFERENCES referrals (id)
);

-- ---------------------------------------------------------------------------
-- 7. agent_logs — audit trail of every agent action
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS agent_logs (
    id           INT          NOT NULL AUTO_INCREMENT,
    referral_id  INT          DEFAULT NULL,      -- nullable: some logs have no referral
    agent_name   VARCHAR(100) NOT NULL,
    action_taken TEXT         NOT NULL,
    timestamp    DATETIME     DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    CONSTRAINT fk_log_referral FOREIGN KEY (referral_id) REFERENCES referrals (id)
);
