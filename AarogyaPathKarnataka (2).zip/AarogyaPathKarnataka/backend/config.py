"""
config.py — Load environment variables and provide database helpers.

All configuration values come from the .env file (never hardcoded).
Call get_db_session() inside routes to talk to MySQL.
"""

import os
from urllib.parse import quote_plus
from dotenv import load_dotenv
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base

# Load values from .env into os.environ
load_dotenv()

# --- watsonx.ai settings ---
WATSONX_API_KEY    = os.getenv("WATSONX_API_KEY", "")
WATSONX_PROJECT_ID = os.getenv("WATSONX_PROJECT_ID", "")
WATSONX_URL        = os.getenv("WATSONX_URL", "https://us-south.ml.cloud.ibm.com")
WATSONX_MODEL_ID   = os.getenv("WATSONX_MODEL_ID", "ibm/granite-13b-instruct-v2")

# --- MySQL connection settings ---
DB_HOST     = os.getenv("DB_HOST", "localhost")
DB_PORT     = os.getenv("DB_PORT", "3306")
DB_USER     = os.getenv("DB_USER", "root")
DB_PASSWORD = os.getenv("DB_PASSWORD", "")
DB_NAME     = os.getenv("DB_NAME", "aarogya_path")

# --- Flask settings ---
SECRET_KEY = os.getenv("SECRET_KEY", "dev-secret-key-change-in-production")

# URL-encode the password so special characters like @ # ! do not break the connection URL
DATABASE_URL = (
    f"mysql+pymysql://{quote_plus(DB_USER)}:{quote_plus(DB_PASSWORD)}"
    f"@{DB_HOST}:{DB_PORT}/{DB_NAME}?charset=utf8mb4"
)

# SQLAlchemy base class — all ORM models inherit from this
Base = declarative_base()


def get_db_engine():
    """
    Create and return a SQLAlchemy engine connected to MySQL.
    Call this once at app startup.
    """
    return create_engine(DATABASE_URL, echo=False)


def get_db_session(engine=None):
    """
    Return a new SQLAlchemy session bound to the given engine.
    If no engine is passed, a new one is created automatically.

    Usage:
        session = get_db_session()
        results = session.query(Patient).all()
        session.close()
    """
    if engine is None:
        engine = get_db_engine()
    Session = sessionmaker(bind=engine)
    return Session()
