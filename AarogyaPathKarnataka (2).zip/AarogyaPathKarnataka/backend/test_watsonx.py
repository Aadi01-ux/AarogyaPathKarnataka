"""
test_watsonx.py — Quick connection test for the IBM Granite integration.

Run from the backend/ directory:
    python test_watsonx.py

If WATSONX_API_KEY is a placeholder, this test will explain that gracefully.
"""

import sys
import os

# Put backend/ on the path so config.py and watsonx_client.py are importable
sys.path.insert(0, os.path.dirname(__file__))

from watsonx_client import generate

print("Testing IBM Granite connection...")
print("-" * 50)

result = generate("In one sentence, what is the purpose of a medical referral?")

print("Response:", result)

if result.startswith("ERROR:"):
    print("\n[INFO] The test returned an error. Check the message above.")
    print("       If the API key is a placeholder, update WATSONX_API_KEY in .env")
else:
    print("\n[OK] IBM Granite responded successfully.")
