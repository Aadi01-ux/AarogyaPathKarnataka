import sys; sys.path.insert(0,'backend')
import requests

s = requests.Session()
s.post('http://127.0.0.1:5000/api/auth/login', json={'username':'admin','password':'Admin@1234'})

for rid in [9, 10, 11, 12]:
    r = s.post('http://127.0.0.1:5000/api/referral/' + str(rid) + '/reminder', json={'consent_given': True})
    d = r.json()
    err = (d.get('error') or '')[:80]
    print('Referral', rid, '| success:', d.get('success'), '| error:', err)

# Also check the journey double-nesting issue
r2 = s.get('http://127.0.0.1:5000/api/referral/3/journey')
d2 = r2.json()
print()
print('Journey outer keys:', list(d2.keys()))
print('Journey data keys:', list(d2.get('data', {}).keys()))
inner = d2.get('data', {})
print('steps in data.steps:', len(inner.get('steps', [])))
# Check what dashboard.js reads: data.data.steps
print('data.data would be:', type(d2.get('data')))
