"""
orchestrator.py — Central router. All agent calls go through here.

Routes are named clearly so beginners can follow the flow.
No business logic lives here — this is purely a dispatch layer.
"""

import sys
import os

# Ensure backend/ is on the path
sys.path.insert(0, os.path.dirname(__file__))

from agents import (
    referral_processing_agent,
    care_journey_agent,
    multilingual_agent,
    reminder_agent,
    status_tracking_agent,
    dashboard_agent
)


def process_referral(patient_id: int, document_text: str) -> dict:
    """Route to: ReferralProcessingAgent — extracts fields from document text."""
    return referral_processing_agent.process(patient_id, document_text)


def get_care_journey(referral_id: int) -> dict:
    """Route to: CareJourneyAgent — builds care steps for a referral."""
    return care_journey_agent.build_journey(referral_id)


def get_referral_status(referral_id: int) -> dict:
    """Route to: StatusTrackingAgent — returns referral + appointments + tasks."""
    return status_tracking_agent.get_status(referral_id)


def translate_instructions(text: str, target_language: str) -> dict:
    """Route to: MultilingualAgent — translates text to 'en' or 'kn'."""
    return multilingual_agent.translate_text(text, target_language)


def create_reminder(referral_id: int, consent_given: bool) -> dict:
    """Route to: ReminderAgent — generates reminder (requires consent)."""
    return reminder_agent.generate_reminder(referral_id, consent_given)


def get_dashboard() -> dict:
    """Route to: DashboardAgent — returns counts and recent referrals."""
    return dashboard_agent.get_summary()
