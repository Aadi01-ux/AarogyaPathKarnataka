"""
db_models.py — SQLAlchemy ORM models for Aarogya Path Karnataka.

Each class maps to one MySQL table. All models inherit from Base
(defined in config.py). Column types and constraints match the
Database Design section of the project plan.

Tables:
  1. StaffUser      — healthcare staff who can log in
  2. Patient        — synthetic patient records
  3. Referral       — a doctor's referral for a patient
  4. Appointment    — a scheduled visit or lab test
  5. Task           — an administrative task tied to a referral
  6. Reminder       — a reminder message for the patient
  7. AgentLog       — audit log of every agent action
"""

from datetime import datetime
from sqlalchemy import (
    Column, Integer, String, Text, Boolean,
    DateTime, ForeignKey, JSON
)
from config import Base  # Base = declarative_base() in config.py


# ---------------------------------------------------------------------------
# 1. StaffUser — healthcare staff who log into the app
# ---------------------------------------------------------------------------
class StaffUser(Base):
    __tablename__ = "staff_users"

    id            = Column(Integer, primary_key=True, autoincrement=True)
    username      = Column(String(100), unique=True, nullable=False)
    password_hash = Column(String(255), nullable=False)   # bcrypt hash
    full_name     = Column(String(200), nullable=False)
    role          = Column(String(50), nullable=False)    # 'admin' or 'coordinator'
    created_at    = Column(DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f"<StaffUser {self.username} ({self.role})>"


# ---------------------------------------------------------------------------
# 2. Patient — synthetic patient records (no real patient data)
# ---------------------------------------------------------------------------
class Patient(Base):
    __tablename__ = "patients"

    id              = Column(Integer, primary_key=True, autoincrement=True)
    name            = Column(String(200), nullable=False)
    village         = Column(String(200))                 # village or taluk name
    phone           = Column(String(20))                  # synthetic phone number
    language_pref   = Column(String(10), default="en")    # 'en' or 'kn' (Kannada)
    consent_on_file = Column(Boolean, default=False)      # general consent flag
    created_at      = Column(DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f"<Patient {self.name} ({self.village})>"


# ---------------------------------------------------------------------------
# 3. Referral — a specialist referral created from an uploaded document
# ---------------------------------------------------------------------------
class Referral(Base):
    __tablename__ = "referrals"

    id                = Column(Integer, primary_key=True, autoincrement=True)
    patient_id        = Column(Integer, ForeignKey("patients.id"), nullable=False)
    referring_doctor  = Column(String(200))
    specialist_needed = Column(String(200))
    urgency           = Column(String(20))                # 'high', 'medium', 'low'
    status            = Column(String(30), default="pending")
    # 'pending', 'confirmed', 'completed', 'unconfirmed'
    raw_document_text = Column(Text)                      # original uploaded text
    extracted_data    = Column(JSON)                      # fields parsed by Granite
    created_at        = Column(DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f"<Referral id={self.id} status={self.status}>"


# ---------------------------------------------------------------------------
# 4. Appointment — a scheduled specialist visit, lab test, or follow-up
# ---------------------------------------------------------------------------
class Appointment(Base):
    __tablename__ = "appointments"

    id           = Column(Integer, primary_key=True, autoincrement=True)
    referral_id  = Column(Integer, ForeignKey("referrals.id"), nullable=False)
    type         = Column(String(50))
    # 'specialist_visit', 'lab_test', 'follow_up'
    location     = Column(String(300))                    # hospital or lab name
    scheduled_at = Column(DateTime)
    status       = Column(String(30), default="pending")
    # 'pending', 'completed', 'cancelled'

    def __repr__(self):
        return f"<Appointment id={self.id} type={self.type} status={self.status}>"


# ---------------------------------------------------------------------------
# 5. Task — an administrative task linked to a referral
# ---------------------------------------------------------------------------
class Task(Base):
    __tablename__ = "tasks"

    id          = Column(Integer, primary_key=True, autoincrement=True)
    referral_id = Column(Integer, ForeignKey("referrals.id"), nullable=False)
    description = Column(Text, nullable=False)
    completed   = Column(Boolean, default=False)
    created_at  = Column(DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f"<Task id={self.id} completed={self.completed}>"


# ---------------------------------------------------------------------------
# 6. Reminder — a patient reminder message (requires consent before sending)
# ---------------------------------------------------------------------------
class Reminder(Base):
    __tablename__ = "reminders"

    id            = Column(Integer, primary_key=True, autoincrement=True)
    referral_id   = Column(Integer, ForeignKey("referrals.id"), nullable=False)
    message_en    = Column(Text)                          # English reminder text
    message_kn    = Column(Text)                          # Kannada reminder text
    consent_given = Column(Boolean, default=False)        # must be True before sending
    sent_at       = Column(DateTime, nullable=True)       # NULL until dispatched

    def __repr__(self):
        return f"<Reminder id={self.id} consent={self.consent_given} sent={self.sent_at}>"


# ---------------------------------------------------------------------------
# 7. AgentLog — audit trail of every action taken by any agent
# ---------------------------------------------------------------------------
class AgentLog(Base):
    __tablename__ = "agent_logs"

    id           = Column(Integer, primary_key=True, autoincrement=True)
    referral_id  = Column(Integer, ForeignKey("referrals.id"), nullable=True)
    # nullable — some logs may not relate to a specific referral
    agent_name   = Column(String(100), nullable=False)   # e.g. 'ReferralProcessingAgent'
    action_taken = Column(Text, nullable=False)
    timestamp    = Column(DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f"<AgentLog agent={self.agent_name} at={self.timestamp}>"


# ---------------------------------------------------------------------------
# 8. PatientUser — login credentials for the patient-facing portal
#    Links a username/password to an existing Patient record.
#    The patients table itself is never modified by this model.
# ---------------------------------------------------------------------------
class PatientUser(Base):
    __tablename__ = "patient_users"

    id            = Column(Integer, primary_key=True, autoincrement=True)
    patient_id    = Column(Integer, ForeignKey("patients.id"), unique=True, nullable=False)
    # unique=True: one portal account per patient
    username      = Column(String(100), unique=True, nullable=False)
    password_hash = Column(String(255), nullable=False)   # bcrypt hash
    created_at    = Column(DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f"<PatientUser {self.username} patient_id={self.patient_id}>"
