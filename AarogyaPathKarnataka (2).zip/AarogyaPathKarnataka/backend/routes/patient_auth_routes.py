"""
patient_auth_routes.py — Patient portal authentication endpoints.

POST /api/patient/auth/register — create a patient_users account linked to an
                                   existing patients record (matched by phone)
POST /api/patient/auth/login    — verify credentials, set patient session cookie
POST /api/patient/auth/logout   — clear patient session keys
GET  /api/patient/auth/me       — return current patient info

Patient session keys:
    session["patient_user_id"]     — PatientUser.id
    session["patient_id"]          — Patient.id  (used for ownership checks)
    session["patient_name"]        — Patient.name
    session["patient_language"]    — Patient.language_pref ('en' or 'kn')
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

import bcrypt
from flask import Blueprint, jsonify, request, session
from config import get_db_session
from models.db_models import Patient, PatientUser

patient_auth_bp = Blueprint("patient_auth", __name__)


# ---------------------------------------------------------------------------
# POST /api/patient/auth/register
# ---------------------------------------------------------------------------
@patient_auth_bp.route("/api/patient/auth/register", methods=["POST"])
def patient_register():
    """
    Register a new patient portal account.

    The patient must already exist in the patients table (added by staff).
    We match them by phone number so they don't need to know their patient ID.

    Expected JSON body:
        {
            "phone":    "9876543210",   -- must match a patients.phone value
            "username": "raju123",
            "password": "..."          -- min 6 characters
        }

    Returns:
        201 {"success": true, "data": {"patient_name": ..., "language": ...}}
        400 for missing / invalid fields, duplicate username, phone not found
    """
    data     = request.get_json(silent=True) or {}
    phone    = (data.get("phone")    or "").strip()
    username = (data.get("username") or "").strip()
    password = data.get("password")  or ""

    # --- Validation ---
    if not phone or not username or not password:
        return jsonify({
            "success": False,
            "error": "phone, username, and password are required."
        }), 400

    if len(password) < 6:
        return jsonify({
            "success": False,
            "error": "Password must be at least 6 characters."
        }), 400

    db = get_db_session()
    try:
        # Find the patient by phone number
        patient = db.query(Patient).filter_by(phone=phone).first()
        if patient is None:
            return jsonify({
                "success": False,
                "error": "No patient record found with that phone number. "
                         "Please contact your healthcare centre."
            }), 400

        # Check that this patient doesn't already have an account
        existing = db.query(PatientUser).filter_by(patient_id=patient.id).first()
        if existing is not None:
            return jsonify({
                "success": False,
                "error": "A portal account already exists for this patient. "
                         "Please log in."
            }), 400

        # Check username uniqueness
        taken = db.query(PatientUser).filter_by(username=username).first()
        if taken is not None:
            return jsonify({
                "success": False,
                "error": "That username is already taken. Please choose another."
            }), 400

        # Hash the password with bcrypt
        pw_hash = bcrypt.hashpw(
            password.encode("utf-8"),
            bcrypt.gensalt()
        ).decode("utf-8")

        new_user = PatientUser(
            patient_id    = patient.id,
            username      = username,
            password_hash = pw_hash
        )
        db.add(new_user)
        db.commit()
        db.refresh(new_user)

        return jsonify({
            "success": True,
            "data": {
                "patient_name": patient.name,
                "language":     patient.language_pref
            }
        }), 201

    except Exception as e:
        db.rollback()
        return jsonify({"success": False, "error": str(e)}), 500
    finally:
        db.close()


# ---------------------------------------------------------------------------
# POST /api/patient/auth/login
# ---------------------------------------------------------------------------
@patient_auth_bp.route("/api/patient/auth/login", methods=["POST"])
def patient_login():
    """
    Authenticate a patient and start a patient portal session.

    Expected JSON body:
        {"username": "raju123", "password": "..."}

    Returns:
        200 {"success": true, "data": {"patient_name": ..., "language": ...}}
        400 missing fields
        401 wrong credentials
    """
    data     = request.get_json(silent=True) or {}
    username = (data.get("username") or "").strip()
    password = data.get("password")  or ""

    if not username or not password:
        return jsonify({
            "success": False,
            "error": "Username and password are required."
        }), 400

    db = get_db_session()
    try:
        pu = db.query(PatientUser).filter_by(username=username).first()
        if pu is None:
            return jsonify({
                "success": False,
                "error": "Invalid username or password."
            }), 401

        if not bcrypt.checkpw(
            password.encode("utf-8"),
            pu.password_hash.encode("utf-8")
        ):
            return jsonify({
                "success": False,
                "error": "Invalid username or password."
            }), 401

        # Load patient details for session
        patient = db.query(Patient).filter_by(id=pu.patient_id).first()

        session["patient_user_id"] = pu.id
        session["patient_id"]      = patient.id
        session["patient_name"]    = patient.name
        session["patient_language"] = patient.language_pref or "en"

        return jsonify({
            "success": True,
            "data": {
                "patient_name": patient.name,
                "language":     session["patient_language"],
                "village":      patient.village
            }
        })

    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500
    finally:
        db.close()


# ---------------------------------------------------------------------------
# POST /api/patient/auth/logout
# ---------------------------------------------------------------------------
@patient_auth_bp.route("/api/patient/auth/logout", methods=["POST"])
def patient_logout():
    """Clear the patient session keys (staff session untouched)."""
    session.pop("patient_user_id", None)
    session.pop("patient_id",      None)
    session.pop("patient_name",    None)
    session.pop("patient_language", None)
    return jsonify({"success": True, "message": "Logged out"})


# ---------------------------------------------------------------------------
# GET /api/patient/auth/me
# ---------------------------------------------------------------------------
@patient_auth_bp.route("/api/patient/auth/me", methods=["GET"])
def patient_me():
    """
    Return info about the currently logged-in patient.
    Used by the patient portal on page load to check for a live session.
    """
    if "patient_user_id" not in session:
        return jsonify({
            "success": False,
            "error": "Unauthorized. Please log in."
        }), 401

    return jsonify({
        "success": True,
        "data": {
            "patient_name": session.get("patient_name"),
            "language":     session.get("patient_language", "en")
        }
    })
