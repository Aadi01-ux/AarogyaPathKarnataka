"""
api_routes.py — Protected REST API endpoints for Aarogya Path Karnataka.

All routes require the staff member to be logged in (@login_required).
The orchestrator handles all agent dispatching — routes only do HTTP work.

Endpoints:
  POST   /api/referral/upload          — upload & extract referral document
  GET    /api/referral/<id>            — get referral details and status
  GET    /api/referral/<id>/journey    — get full care timeline
  POST   /api/referral/<id>/translate  — translate instructions to patient language
  POST   /api/referral/<id>/reminder   — generate and store a reminder
  GET    /api/dashboard                — summary of all referrals
  GET    /api/patients                 — list all synthetic patients
  POST   /api/seed                     — load synthetic seed data
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from flask import Blueprint, jsonify, request
from auth import login_required
from config import get_db_session
from models.db_models import Referral, Patient
import orchestrator

# 'api' is the blueprint name used when registering in app.py
api_bp = Blueprint("api", __name__)


# ---------------------------------------------------------------------------
# Input validation helpers
# ---------------------------------------------------------------------------

def validate_referral_id(referral_id: int):
    """
    Check that referral_id is a positive integer that exists in the DB.

    Returns:
        (referral_object, None)   if valid
        (None, error_response)    if invalid — caller should return the response
    """
    if not isinstance(referral_id, int) or referral_id <= 0:
        return None, (
            jsonify({"success": False, "error": "Invalid referral ID."}), 400
        )
    db = get_db_session()
    try:
        referral = db.query(Referral).filter_by(id=referral_id).first()
        if referral is None:
            return None, (
                jsonify({"success": False, "error": f"Referral {referral_id} not found."}),
                404
            )
        return referral, None
    finally:
        db.close()


# ---------------------------------------------------------------------------
# POST /api/referral/upload — Referral Processing Agent
# ---------------------------------------------------------------------------
@api_bp.route("/api/referral/upload", methods=["POST"])
@login_required
def upload_referral():
    """
    Accept uploaded document text and extract referral details using Granite.

    Expected JSON body:
        {"patient_id": 1, "document_text": "Patient referred to ..."}

    Returns:
        {"success": true, "data": {"referral_id": ..., "extracted": {...}}}
    """
    data = request.get_json(silent=True) or {}
    patient_id    = data.get("patient_id")
    document_text = (data.get("document_text") or "").strip()

    # --- Validation ---
    if not patient_id:
        return jsonify({
            "success": False,
            "error": "patient_id is required."
        }), 400

    if not document_text:
        return jsonify({
            "success": False,
            "error": "document_text is required and cannot be empty."
        }), 400

    if len(document_text) > 5000:
        return jsonify({
            "success": False,
            "error": "document_text exceeds the 5000 character limit."
        }), 400

    # Verify patient exists
    db = get_db_session()
    try:
        patient = db.query(Patient).filter_by(id=patient_id).first()
        if patient is None:
            return jsonify({
                "success": False,
                "error": f"Patient {patient_id} not found."
            }), 404
    finally:
        db.close()

    # --- Process via orchestrator ---
    result = orchestrator.process_referral(int(patient_id), document_text)

    if result.get("success"):
        return jsonify({"success": True, "data": result})
    else:
        return jsonify({"success": False, "error": result.get("error", "Processing failed.")}), 500


# ---------------------------------------------------------------------------
# GET /api/referral/<id> — Status Tracking Agent
# ---------------------------------------------------------------------------
@api_bp.route("/api/referral/<int:referral_id>", methods=["GET"])
@login_required
def get_referral(referral_id):
    """Return details and current status for a single referral."""
    _, err = validate_referral_id(referral_id)
    if err:
        return err

    result = orchestrator.get_referral_status(referral_id)
    if result.get("success"):
        return jsonify({"success": True, "data": result})
    else:
        return jsonify({"success": False, "error": result.get("error")}), 500


# ---------------------------------------------------------------------------
# GET /api/referral/<id>/journey — Care Journey Agent
# ---------------------------------------------------------------------------
@api_bp.route("/api/referral/<int:referral_id>/journey", methods=["GET"])
@login_required
def get_journey(referral_id):
    """Return (or generate) the full care timeline for a referral."""
    _, err = validate_referral_id(referral_id)
    if err:
        return err

    result = orchestrator.get_care_journey(referral_id)
    if result.get("success"):
        return jsonify({"success": True, "data": result})
    else:
        return jsonify({"success": False, "error": result.get("error")}), 500


# ---------------------------------------------------------------------------
# POST /api/referral/<id>/translate — Multilingual Assistance Agent
# ---------------------------------------------------------------------------
@api_bp.route("/api/referral/<int:referral_id>/translate", methods=["POST"])
@login_required
def translate_instructions(referral_id):
    """
    Translate patient instructions to Kannada or English.

    Expected JSON body:
        {"text": "...", "target_language": "kn"}
    """
    _, err = validate_referral_id(referral_id)
    if err:
        return err

    data = request.get_json(silent=True) or {}
    text            = (data.get("text") or "").strip()
    target_language = (data.get("target_language") or "").strip()

    if not text:
        return jsonify({"success": False, "error": "text is required."}), 400

    if target_language not in ("en", "kn"):
        return jsonify({
            "success": False,
            "error": "target_language must be 'en' or 'kn'."
        }), 400

    result = orchestrator.translate_instructions(text, target_language)
    if result.get("success"):
        return jsonify({"success": True, "data": result})
    else:
        return jsonify({"success": False, "error": result.get("error")}), 500


# ---------------------------------------------------------------------------
# POST /api/referral/<id>/reminder — Reminder Agent
# ---------------------------------------------------------------------------
@api_bp.route("/api/referral/<int:referral_id>/reminder", methods=["POST"])
@login_required
def create_reminder(referral_id):
    """
    Generate and store a patient reminder (requires consent).

    Expected JSON body:
        {"consent_given": true}
    """
    _, err = validate_referral_id(referral_id)
    if err:
        return err

    data = request.get_json(silent=True) or {}
    consent_given = bool(data.get("consent_given", False))

    result = orchestrator.create_reminder(referral_id, consent_given)
    if result.get("success"):
        return jsonify({"success": True, "data": result})
    else:
        # 400 for consent/validation issues, 500 for system errors
        status_code = 400 if "consent" in result.get("error", "").lower() else 500
        return jsonify({"success": False, "error": result.get("error")}), status_code


# ---------------------------------------------------------------------------
# GET /api/dashboard — Dashboard Agent
# ---------------------------------------------------------------------------
@api_bp.route("/api/dashboard", methods=["GET"])
@login_required
def get_dashboard():
    """Return aggregated referral counts and recent referrals for the dashboard."""
    result = orchestrator.get_dashboard()
    if result.get("success"):
        return jsonify({"success": True, "data": result})
    else:
        return jsonify({"success": False, "error": result.get("error")}), 500


# ---------------------------------------------------------------------------
# GET /api/patients — list all patients
# POST /api/patients — create a new patient (admin only)
# ---------------------------------------------------------------------------
@api_bp.route("/api/patients", methods=["GET"])
@login_required
def get_patients():
    """Return the list of all patients."""
    db = get_db_session()
    try:
        patients = db.query(Patient).order_by(Patient.name).all()
        patients_data = [
            {
                "id":              p.id,
                "name":            p.name,
                "village":         p.village,
                "phone":           p.phone,
                "language_pref":   p.language_pref,
                "consent_on_file": p.consent_on_file
            }
            for p in patients
        ]
        return jsonify({"success": True, "data": {"patients": patients_data}})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500
    finally:
        db.close()


@api_bp.route("/api/patients", methods=["POST"])
@login_required
def create_patient():
    """
    Create a new patient record. Admin role required.

    Expected JSON body:
        {
            "name":            "Ravi Kumar",          -- required
            "village":         "Hesaraghatta",        -- optional
            "phone":           "+91-9876500001",      -- optional
            "language_pref":   "en",                  -- optional, 'en' or 'kn'
            "consent_on_file": true                   -- optional, default false
        }

    Returns:
        201 {"success": true, "data": {"patient": {...}}}
        400 for missing/invalid fields
        403 if the logged-in user is not an admin
    """
    from flask import session as flask_session
    # Only admins may create patients
    if flask_session.get("staff_role") != "admin":
        return jsonify({
            "success": False,
            "error": "Only admin users can add patients."
        }), 403

    data = request.get_json(silent=True) or {}
    name           = (data.get("name")    or "").strip()
    village        = (data.get("village") or "").strip() or None
    phone          = (data.get("phone")   or "").strip() or None
    language_pref  = (data.get("language_pref") or "en").strip().lower()
    consent_on_file = bool(data.get("consent_on_file", False))

    if not name:
        return jsonify({"success": False, "error": "Patient name is required."}), 400

    if language_pref not in ("en", "kn"):
        return jsonify({"success": False, "error": "language_pref must be 'en' or 'kn'."}), 400

    db = get_db_session()
    try:
        # Prevent duplicate phone numbers
        if phone:
            existing = db.query(Patient).filter_by(phone=phone).first()
            if existing:
                return jsonify({
                    "success": False,
                    "error": f"A patient with phone '{phone}' already exists."
                }), 400

        patient = Patient(
            name            = name,
            village         = village,
            phone           = phone,
            language_pref   = language_pref,
            consent_on_file = consent_on_file
        )
        db.add(patient)
        db.commit()
        db.refresh(patient)

        return jsonify({
            "success": True,
            "data": {
                "patient": {
                    "id":              patient.id,
                    "name":            patient.name,
                    "village":         patient.village,
                    "phone":           patient.phone,
                    "language_pref":   patient.language_pref,
                    "consent_on_file": patient.consent_on_file
                }
            }
        }), 201

    except Exception as e:
        db.rollback()
        return jsonify({"success": False, "error": str(e)}), 500
    finally:
        db.close()


# ---------------------------------------------------------------------------
# POST /api/seed — load synthetic seed data
# ---------------------------------------------------------------------------
@api_bp.route("/api/seed", methods=["POST"])
@login_required
def seed_data():
    """Trigger loading of synthetic seed data into the database."""
    try:
        # Import here to avoid circular imports at module load time
        import seed_data as sd
        sd.main()
        return jsonify({"success": True, "message": "Seed data loaded successfully."})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500
