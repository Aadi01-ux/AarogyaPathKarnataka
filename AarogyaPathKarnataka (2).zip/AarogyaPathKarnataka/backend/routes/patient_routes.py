"""
patient_routes.py — Read-only patient portal API endpoints.

All routes require a valid patient session (@patient_login_required).
Every query is filtered by the patient_id stored in the session so a
patient can only ever access their own records.

Endpoints:
  GET  /api/patient/referrals              — list own referrals
  GET  /api/patient/referral/<id>          — detail of one referral (ownership enforced)
  GET  /api/patient/referral/<id>/journey  — care journey timeline (read-only)
  GET  /api/patient/referral/<id>/reminders— reminders for this referral
  GET  /api/patient/appointments           — upcoming appointments across all referrals
  POST /api/patient/language               — update language preference ('en' or 'kn')
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from flask import Blueprint, jsonify, request, session
from auth import patient_login_required
from config import get_db_session
from models.db_models import Referral, Appointment, Reminder, Patient
import orchestrator

patient_bp = Blueprint("patient", __name__)


# ---------------------------------------------------------------------------
# Helper: verify referral belongs to the logged-in patient
# ---------------------------------------------------------------------------
def _own_referral(referral_id: int, patient_id: int):
    """
    Returns (referral, None) if the referral exists and belongs to patient_id.
    Returns (None, error_response_tuple) otherwise.
    """
    db = get_db_session()
    try:
        referral = db.query(Referral).filter_by(id=referral_id).first()
        if referral is None:
            return None, (
                jsonify({"success": False, "error": "Referral not found."}), 404
            )
        if referral.patient_id != patient_id:
            # Return generic 404 so patients cannot enumerate other patients' IDs
            return None, (
                jsonify({"success": False, "error": "Referral not found."}), 404
            )
        return referral, None
    finally:
        db.close()


# ---------------------------------------------------------------------------
# GET /api/patient/referrals — list own referrals
# ---------------------------------------------------------------------------
@patient_bp.route("/api/patient/referrals", methods=["GET"])
@patient_login_required
def list_my_referrals():
    """
    Return a summary list of all referrals for the logged-in patient.
    Fields are limited to what the patient needs — no raw document text.
    """
    patient_id = session["patient_id"]
    db = get_db_session()
    try:
        referrals = (
            db.query(Referral)
            .filter_by(patient_id=patient_id)
            .order_by(Referral.created_at.desc())
            .all()
        )
        data = [
            {
                "id":                r.id,
                "specialist_needed": r.specialist_needed,
                "referring_doctor":  r.referring_doctor,
                "urgency":           r.urgency,
                "status":            r.status,
                "created_at":        r.created_at.isoformat() if r.created_at else None
            }
            for r in referrals
        ]
        return jsonify({"success": True, "data": {"referrals": data}})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500
    finally:
        db.close()


# ---------------------------------------------------------------------------
# GET /api/patient/referral/<id> — detail of one referral
# ---------------------------------------------------------------------------
@patient_bp.route("/api/patient/referral/<int:referral_id>", methods=["GET"])
@patient_login_required
def get_my_referral(referral_id):
    """
    Return full status details for a single referral owned by the patient.
    Delegates to the status_tracking_agent via orchestrator (read-only).
    """
    patient_id = session["patient_id"]
    _, err = _own_referral(referral_id, patient_id)
    if err:
        return err

    result = orchestrator.get_referral_status(referral_id)
    if result.get("success"):
        return jsonify({"success": True, "data": result})
    return jsonify({"success": False, "error": result.get("error")}), 500


# ---------------------------------------------------------------------------
# GET /api/patient/referral/<id>/journey — care journey timeline
# ---------------------------------------------------------------------------
@patient_bp.route("/api/patient/referral/<int:referral_id>/journey", methods=["GET"])
@patient_login_required
def get_my_journey(referral_id):
    """
    Return the care journey steps for a referral owned by the patient.
    Uses care_journey_agent via orchestrator (read-only).
    """
    patient_id = session["patient_id"]
    _, err = _own_referral(referral_id, patient_id)
    if err:
        return err

    result = orchestrator.get_care_journey(referral_id)
    if result.get("success"):
        return jsonify({"success": True, "data": result})
    return jsonify({"success": False, "error": result.get("error")}), 500


# ---------------------------------------------------------------------------
# GET /api/patient/referral/<id>/reminders — reminders for this referral
# ---------------------------------------------------------------------------
@patient_bp.route("/api/patient/referral/<int:referral_id>/reminders", methods=["GET"])
@patient_login_required
def get_my_reminders(referral_id):
    """
    Return all reminders linked to a referral owned by the patient.
    Returns the language-appropriate message based on session["patient_language"].
    """
    patient_id = session["patient_id"]
    _, err = _own_referral(referral_id, patient_id)
    if err:
        return err

    language = session.get("patient_language", "en")
    db = get_db_session()
    try:
        reminders = (
            db.query(Reminder)
            .filter_by(referral_id=referral_id)
            .order_by(Reminder.id.desc())
            .all()
        )
        data = []
        for r in reminders:
            # Show Kannada if preferred and available, otherwise English
            if language == "kn" and r.message_kn:
                message = r.message_kn
            else:
                message = r.message_en
            data.append({
                "id":            r.id,
                "message":       message,
                "message_en":    r.message_en,
                "message_kn":    r.message_kn,
                "consent_given": r.consent_given,
                "sent_at":       r.sent_at.isoformat() if r.sent_at else None
            })
        return jsonify({"success": True, "data": {"reminders": data}})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500
    finally:
        db.close()


# ---------------------------------------------------------------------------
# GET /api/patient/appointments — upcoming appointments (all referrals)
# ---------------------------------------------------------------------------
@patient_bp.route("/api/patient/appointments", methods=["GET"])
@patient_login_required
def get_my_appointments():
    """
    Return all appointments for the logged-in patient, across all referrals.
    Joins appointments → referrals → patient_id filter.
    """
    patient_id = session["patient_id"]
    db = get_db_session()
    try:
        # Get all referral IDs for this patient
        referral_ids = [
            r.id for r in db.query(Referral).filter_by(patient_id=patient_id).all()
        ]

        if not referral_ids:
            return jsonify({"success": True, "data": {"appointments": []}})

        appointments = (
            db.query(Appointment)
            .filter(Appointment.referral_id.in_(referral_ids))
            .order_by(Appointment.scheduled_at.asc())
            .all()
        )
        data = [
            {
                "id":           a.id,
                "referral_id":  a.referral_id,
                "type":         a.type,
                "location":     a.location,
                "scheduled_at": a.scheduled_at.isoformat() if a.scheduled_at else None,
                "status":       a.status
            }
            for a in appointments
        ]
        return jsonify({"success": True, "data": {"appointments": data}})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500
    finally:
        db.close()


# ---------------------------------------------------------------------------
# POST /api/patient/language — update language preference
# ---------------------------------------------------------------------------
@patient_bp.route("/api/patient/language", methods=["POST"])
@patient_login_required
def update_language():
    """
    Update the patient's language preference and refresh the session value.

    Expected JSON body:
        {"language": "kn"}  or  {"language": "en"}
    """
    data     = request.get_json(silent=True) or {}
    language = (data.get("language") or "").strip().lower()

    if language not in ("en", "kn"):
        return jsonify({
            "success": False,
            "error": "language must be 'en' or 'kn'."
        }), 400

    patient_id = session["patient_id"]
    db = get_db_session()
    try:
        patient = db.query(Patient).filter_by(id=patient_id).first()
        patient.language_pref = language
        db.commit()
        session["patient_language"] = language
        return jsonify({"success": True, "data": {"language": language}})
    except Exception as e:
        db.rollback()
        return jsonify({"success": False, "error": str(e)}), 500
    finally:
        db.close()
