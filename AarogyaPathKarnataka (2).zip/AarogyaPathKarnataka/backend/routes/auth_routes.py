"""
auth_routes.py — Staff authentication endpoints.

POST /api/auth/login  — verify username + password, set session cookie
POST /api/auth/logout — clear session cookie
GET  /api/auth/me     — return current logged-in user info
"""

import sys
import os
# Ensure backend/ is on the path when this file is imported
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

import bcrypt
from flask import Blueprint, jsonify, request, session
from config import get_db_session
from models.db_models import StaffUser

# 'auth' is the blueprint name used when registering in app.py
auth_bp = Blueprint("auth", __name__)


# ---------------------------------------------------------------------------
# POST /api/auth/login
# ---------------------------------------------------------------------------
@auth_bp.route("/api/auth/login", methods=["POST"])
def login():
    """
    Accept JSON: { "username": "...", "password": "..." }
    Verify against staff_users table, start a session on success.

    Returns:
        200 {"success": true, "data": {"username": ..., "role": ..., "full_name": ...}}
        400 if username or password missing
        401 if credentials are wrong
    """
    data = request.get_json(silent=True) or {}
    username = (data.get("username") or "").strip()
    password = data.get("password") or ""   # do NOT strip passwords

    # --- Validation ---
    if not username or not password:
        return jsonify({
            "success": False,
            "error": "Username and password are required."
        }), 400

    # --- Look up staff user ---
    db = get_db_session()
    try:
        user = db.query(StaffUser).filter_by(username=username).first()

        # Wrong username — same error message as wrong password (avoid enumeration)
        if user is None:
            return jsonify({
                "success": False,
                "error": "Invalid username or password."
            }), 401

        # Verify bcrypt password (never log the raw password)
        password_matches = bcrypt.checkpw(
            password.encode("utf-8"),
            user.password_hash.encode("utf-8")
        )
        if not password_matches:
            return jsonify({
                "success": False,
                "error": "Invalid username or password."
            }), 401

        # --- Success — set session ---
        session["staff_user_id"]   = user.id
        session["staff_username"]  = user.username
        session["staff_role"]      = user.role
        session["staff_full_name"] = user.full_name

        return jsonify({
            "success": True,
            "data": {
                "username":  user.username,
                "role":      user.role,
                "full_name": user.full_name
            }
        })

    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500
    finally:
        db.close()


# ---------------------------------------------------------------------------
# POST /api/auth/logout
# ---------------------------------------------------------------------------
@auth_bp.route("/api/auth/logout", methods=["POST"])
def logout():
    """Clear the current user's session."""
    session.clear()
    return jsonify({"success": True, "message": "Logged out"})


# ---------------------------------------------------------------------------
# GET /api/auth/me
# ---------------------------------------------------------------------------
@auth_bp.route("/api/auth/me", methods=["GET"])
def me():
    """
    Return info about the currently logged-in user.
    Used by the frontend on page load to check whether a session exists.

    Returns:
        200 {"success": true, "data": {"username": ..., "role": ..., "full_name": ...}}
        401 if not logged in
    """
    if "staff_user_id" not in session:
        return jsonify({
            "success": False,
            "error": "Unauthorized. Please log in."
        }), 401

    return jsonify({
        "success": True,
        "data": {
            "username":  session.get("staff_username"),
            "role":      session.get("staff_role"),
            "full_name": session.get("staff_full_name")
        }
    })
