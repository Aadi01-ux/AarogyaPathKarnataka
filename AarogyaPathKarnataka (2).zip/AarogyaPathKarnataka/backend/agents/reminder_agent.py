"""
reminder_agent.py — Reminder Agent

Generates a patient reminder message in both English and Kannada,
then saves it to the reminders table.

Requires explicit consent before creating the reminder.

Entry point: generate_reminder(referral_id, consent_given) -> dict
"""

import sys
import os
from datetime import datetime

# Ensure backend/ is on the path
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from config import get_db_session
from models.db_models import Referral, Patient, Appointment, Reminder, AgentLog
from utils import translate


def generate_reminder(referral_id: int, consent_given: bool) -> dict:
    """
    Generate and save a patient reminder for an upcoming appointment.

    Steps:
      1. Check consent_given param — refuse if False
      2. Fetch referral + patient, re-check patient.consent_on_file
      3. Find the next upcoming appointment for this referral
      4. Build reminder text in English
      5. Translate to Kannada using utils.translate()
      6. Save to reminders table
      7. Log to agent_logs
      8. Return reminder details

    Args:
        referral_id:   ID of the referral
        consent_given: True if the staff member has confirmed verbal consent

    Returns:
        {"success": True,  "reminder_id": ..., "message_en": ..., "message_kn": ...}
        {"success": False, "error": "..."}
    """
    db = get_db_session()
    try:
        # --- Step 1: Check consent from caller ---
        if not consent_given:
            return {
                "success": False,
                "error": "Cannot generate reminder: patient consent has not been confirmed."
            }

        # --- Step 2: Fetch referral and patient ---
        referral = db.query(Referral).filter_by(id=referral_id).first()
        if referral is None:
            return {"success": False, "error": f"Referral {referral_id} not found."}

        patient = db.query(Patient).filter_by(id=referral.patient_id).first()
        if patient is None:
            return {"success": False, "error": "Patient record not found."}

        # Also check patient.consent_on_file (double gate)
        if not patient.consent_on_file:
            return {
                "success": False,
                "error": (
                    "Cannot generate reminder: patient consent is not on file. "
                    "Please obtain and record patient consent first."
                )
            }

        # --- Step 3: Find next upcoming appointment ---
        upcoming = (
            db.query(Appointment)
            .filter_by(referral_id=referral_id, status="pending")
            .order_by(Appointment.scheduled_at)
            .first()
        )

        if upcoming and upcoming.scheduled_at:
            appt_date = upcoming.scheduled_at.strftime("%d %B %Y")
            appt_location = upcoming.location or "the hospital"
            appt_type = upcoming.type or "appointment"
        else:
            appt_date = "a date to be confirmed"
            appt_location = "the designated hospital"
            appt_type = "specialist appointment"

        # --- Step 4: Build English reminder ---
        message_en = (
            f"Dear {patient.name}, this is a reminder for your {appt_type} "
            f"with a {referral.specialist_needed} on {appt_date} "
            f"at {appt_location}. "
            f"Please arrive 15 minutes early and bring your medical records. "
            f"If you have any questions, contact your healthcare coordinator. "
            f"(Synthetic reminder — Aarogya Path Karnataka)"
        )

        # --- Step 5: Translate to Kannada ---
        # translate() returns "[Translation unavailable — ...]" on failure.
        # Either way we store what we get — English reminder is still useful.
        try:
            message_kn = translate(message_en, "kn")
        except Exception:
            message_kn = (
                f"[Kannada translation unavailable — configure WATSONX_API_KEY] "
                f"{message_en}"
            )

        # --- Step 6: Save to reminders table ---
        reminder = Reminder(
            referral_id=referral_id,
            message_en=message_en,
            message_kn=message_kn,
            consent_given=True,
            sent_at=None   # not sent yet — staff dispatches manually
        )
        db.add(reminder)
        db.flush()

        # --- Step 7: Log ---
        log = AgentLog(
            referral_id=referral_id,
            agent_name="ReminderAgent",
            action_taken=(
                f"Generated reminder for referral_id={referral_id}, "
                f"patient='{patient.name}', appt_date={appt_date}."
            ),
            timestamp=datetime.utcnow()
        )
        db.add(log)
        db.commit()

        # --- Step 8: Return ---
        return {
            "success":    True,
            "reminder_id": reminder.id,
            "message_en": message_en,
            "message_kn": message_kn
        }

    except Exception as e:
        db.rollback()
        return {"success": False, "error": str(e)}
    finally:
        db.close()
