"""
care_journey_agent.py — Care Journey Agent

Builds a step-by-step care coordination plan for a referral using IBM Granite.
Each step is saved as an Appointment or Task in the database.

Entry point: build_journey(referral_id) -> dict
"""

import sys
import os
import re
import json
from datetime import datetime, timedelta

# Ensure backend/ is on the path
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from config import get_db_session
from models.db_models import Referral, Appointment, Task, AgentLog
from watsonx_client import generate


# ---------------------------------------------------------------------------
# Prompt template
# ---------------------------------------------------------------------------
# Using Granite instruct chat-template format for reliable JSON array output
JOURNEY_PROMPT = (
    "<|system|>\n"
    "You are a healthcare administrative coordinator. Return only valid JSON arrays. "
    "Do not provide medical diagnoses or clinical recommendations.\n"
    "<|user|>\n"
    "A patient is referred to a {specialist_needed} with {urgency} urgency. "
    "List 3-5 administrative care coordination steps as a JSON array. "
    "Each step needs: step_number (int), type (specialist_visit/lab_test/follow_up/admin_task), "
    "description (string), location (use District Hospital (Synthetic) or Govt Lab (Synthetic)). "
    "Return only the JSON array.\n"
    "<|assistant|>\n"
)


def _parse_steps(response: str) -> list:
    """
    Extract a JSON array of steps from the Granite response.
    Returns list of step dicts, or a default single step if parsing fails.
    """
    # Try direct parse
    try:
        data = json.loads(response)
        if isinstance(data, list):
            return data
    except Exception:
        pass

    # Try to find JSON array inside prose
    match = re.search(r'\[.*\]', response, re.DOTALL)
    if match:
        try:
            data = json.loads(match.group())
            if isinstance(data, list):
                return data
        except Exception:
            pass

    # Fallback: single placeholder step so the journey is never empty
    return [{
        "step_number": 1,
        "type": "specialist_visit",
        "description": "Specialist visit (AI parsing unavailable — please update manually).",
        "location": "District Hospital (Synthetic)"
    }]


def build_journey(referral_id: int) -> dict:
    """
    Generate and save care journey steps for a referral.

    Steps:
      1. Fetch referral from DB
      2. Build prompt using specialist + urgency
      3. Call IBM Granite
      4. Parse steps array
      5. Save steps as Appointments (specialist_visit/lab_test/follow_up)
         or Tasks (admin_task)
      6. Log to agent_logs
      7. Return the journey steps
    """
    db = get_db_session()
    try:
        # --- Step 1: Fetch referral ---
        referral = db.query(Referral).filter_by(id=referral_id).first()
        if referral is None:
            return {"success": False, "error": f"Referral {referral_id} not found."}

        # --- Step 2: Build prompt ---
        # Use replace() to avoid errors if specialist name contains { or }
        prompt = (JOURNEY_PROMPT
                  .replace("{specialist_needed}", referral.specialist_needed or "Specialist")
                  .replace("{urgency}", referral.urgency or "medium"))

        # --- Step 3: Call Granite ---
        response = generate(prompt, max_new_tokens=600)

        # --- Step 4: Parse steps ---
        steps = _parse_steps(response)

        # --- Step 5: Save steps to DB ---
        appointment_types = {"specialist_visit", "lab_test", "follow_up"}
        base_date = datetime.utcnow() + timedelta(days=7)
        saved_steps = []

        for step in steps:
            step_type    = step.get("type", "admin_task")
            description  = step.get("description", "Care step")
            location     = step.get("location", "District Hospital (Synthetic)")
            step_number  = step.get("step_number", 1)
            scheduled_at = base_date + timedelta(days=(step_number - 1) * 7)

            if step_type in appointment_types:
                record = Appointment(
                    referral_id=referral_id,
                    type=step_type,
                    location=location,
                    scheduled_at=scheduled_at,
                    status="pending"
                )
            else:
                # admin_task → save as Task
                record = Task(
                    referral_id=referral_id,
                    description=f"[Step {step_number}] {description} @ {location}",
                    completed=False,
                    created_at=datetime.utcnow()
                )

            db.add(record)
            saved_steps.append({
                "step_number": step_number,
                "type":        step_type,
                "description": description,
                "location":    location
            })

        # --- Step 6: Log ---
        log = AgentLog(
            referral_id=referral_id,
            agent_name="CareJourneyAgent",
            action_taken=(
                f"Built care journey for referral_id={referral_id}. "
                f"Steps generated: {len(saved_steps)}."
            ),
            timestamp=datetime.utcnow()
        )
        db.add(log)
        db.commit()

        # --- Step 7: Return ---
        return {
            "success": True,
            "referral_id": referral_id,
            "steps": saved_steps
        }

    except Exception as e:
        db.rollback()
        return {"success": False, "error": str(e)}
    finally:
        db.close()
