"""
status_tracking_agent.py — Status Tracking Agent

Pure DB read — no IBM Granite call.
Returns current status of a referral along with all appointments and tasks.

Entry point: get_status(referral_id) -> dict
"""

import sys
import os

# Ensure backend/ is on the path
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from config import get_db_session
from models.db_models import Referral, Appointment, Task, Patient


def get_status(referral_id: int) -> dict:
    """
    Fetch referral details, all appointments, and all tasks from the DB.

    Args:
        referral_id: ID of the referral to look up.

    Returns:
        {
          "success": True,
          "referral": { ...fields... },
          "appointments": [ {...}, ... ],
          "tasks": [ {...}, ... ]
        }
        or {"success": False, "error": "..."}
    """
    db = get_db_session()
    try:
        # --- Fetch referral ---
        referral = db.query(Referral).filter_by(id=referral_id).first()
        if referral is None:
            return {"success": False, "error": f"Referral {referral_id} not found."}

        # --- Fetch related patient ---
        patient = db.query(Patient).filter_by(id=referral.patient_id).first()

        # --- Fetch appointments ---
        appointments = db.query(Appointment).filter_by(referral_id=referral_id).all()

        # --- Fetch tasks ---
        tasks = db.query(Task).filter_by(referral_id=referral_id).all()

        # --- Serialise into plain dicts (no ORM objects in response) ---
        referral_data = {
            "id":               referral.id,
            "patient_id":       referral.patient_id,
            "patient_name":     patient.name if patient else "Unknown",
            "patient_village":  patient.village if patient else "",
            "patient_phone":    patient.phone if patient else "",
            "language_pref":    patient.language_pref if patient else "en",
            "consent_on_file":  patient.consent_on_file if patient else False,
            "referring_doctor": referral.referring_doctor,
            "specialist_needed": referral.specialist_needed,
            "urgency":          referral.urgency,
            "status":           referral.status,
            "extracted_data":   referral.extracted_data,
            "created_at":       referral.created_at.isoformat() if referral.created_at else None
        }

        appointments_data = [
            {
                "id":           a.id,
                "type":         a.type,
                "location":     a.location,
                "scheduled_at": a.scheduled_at.isoformat() if a.scheduled_at else None,
                "status":       a.status
            }
            for a in appointments
        ]

        tasks_data = [
            {
                "id":          t.id,
                "description": t.description,
                "completed":   t.completed,
                "created_at":  t.created_at.isoformat() if t.created_at else None
            }
            for t in tasks
        ]

        return {
            "success":      True,
            "referral":     referral_data,
            "appointments": appointments_data,
            "tasks":        tasks_data
        }

    except Exception as e:
        return {"success": False, "error": str(e)}
    finally:
        db.close()
