"""
referral_processing_agent.py — Referral Processing Agent

Takes raw referral document text and uses IBM Granite to extract structured
fields (doctor, specialist, urgency, notes). Saves the result to the DB.

Entry point: process(patient_id, document_text) -> dict
"""

import sys
import os
import re
import json
from datetime import datetime

# Ensure backend/ is on the path
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from config import get_db_session
from models.db_models import Referral, AgentLog
from watsonx_client import generate


# ---------------------------------------------------------------------------
# Prompt template
# ---------------------------------------------------------------------------
# Using Granite instruct chat-template format which produces reliable JSON output
EXTRACTION_PROMPT = (
    "<|system|>\n"
    "You are a JSON extractor for healthcare referrals. Return only valid JSON. "
    "Do not provide medical diagnoses or clinical recommendations.\n"
    "<|user|>\n"
    "Extract referring_doctor, specialist_needed, urgency (high/medium/low), notes "
    "from this referral document. Return only the JSON object.\n"
    "Document: {document_text}\n"
    "<|assistant|>\n"
)


def _parse_extracted_json(response: str) -> dict:
    """
    Try to pull a JSON object out of the Granite response.
    Granite sometimes wraps JSON in prose — use regex to find it.
    Returns a dict (possibly with parse_error=True on failure).
    """
    # Attempt 1: direct parse
    try:
        data = json.loads(response)
        if isinstance(data, dict):
            return data
    except Exception:
        pass

    # Attempt 2: find JSON block inside prose
    match = re.search(r'\{.*?\}', response, re.DOTALL)
    if match:
        try:
            data = json.loads(match.group())
            if isinstance(data, dict):
                return data
        except Exception:
            pass

    # Fallback: store raw text so nothing is lost
    return {"raw": response, "parse_error": True}


def _validate_urgency(value) -> str:
    """Return urgency if valid, otherwise default to 'medium'."""
    if value in ("high", "medium", "low"):
        return value
    return "medium"


def process(patient_id: int, document_text: str) -> dict:
    """
    Extract referral fields from document_text using IBM Granite, save to DB.

    Steps:
      1. Build extraction prompt
      2. Call watsonx_client.generate()
      3. Parse JSON from response (handles prose-wrapped JSON)
      4. Save Referral to DB
      5. Log to agent_logs
      6. Return {"success": True/False, "referral_id": ..., "extracted": {...}}
    """
    db = get_db_session()
    try:
        # --- Step 1: Build prompt ---
        # Use replace() instead of format() to avoid errors when document_text contains { or }
        prompt = EXTRACTION_PROMPT.replace("{document_text}", document_text)

        # --- Step 2: Call Granite ---
        response = generate(prompt, max_new_tokens=300)

        # --- Step 3: Parse extracted fields ---
        extracted = _parse_extracted_json(response)

        # Validate / normalise urgency
        urgency = _validate_urgency(extracted.get("urgency", "medium"))

        # --- Step 4: Save Referral to DB ---
        referral = Referral(
            patient_id=patient_id,
            referring_doctor=extracted.get("referring_doctor", "Unknown"),
            specialist_needed=extracted.get("specialist_needed", "Unknown"),
            urgency=urgency,
            status="pending",
            raw_document_text=document_text,
            extracted_data=extracted,
            created_at=datetime.utcnow()
        )
        db.add(referral)
        db.flush()   # get referral.id before logging

        # --- Step 5: Log the action ---
        log = AgentLog(
            referral_id=referral.id,
            agent_name="ReferralProcessingAgent",
            action_taken=(
                f"Extracted referral for patient_id={patient_id}. "
                f"Specialist: {referral.specialist_needed}, Urgency: {urgency}. "
                f"Parse error: {extracted.get('parse_error', False)}"
            ),
            timestamp=datetime.utcnow()
        )
        db.add(log)
        db.commit()

        # --- Step 6: Return result ---
        return {
            "success": True,
            "referral_id": referral.id,
            "extracted": extracted
        }

    except Exception as e:
        db.rollback()
        return {"success": False, "error": str(e)}
    finally:
        db.close()
