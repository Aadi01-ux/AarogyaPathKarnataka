"""
dashboard_agent.py — Dashboard Agent

Pure DB read — no IBM Granite call.
Returns aggregated statistics and recent referrals for the dashboard view.

Entry point: get_summary() -> dict
"""

import sys
import os

# Ensure backend/ is on the path
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from config import get_db_session
from models.db_models import Referral, Patient


def get_summary() -> dict:
    """
    Fetch dashboard statistics and the 10 most recent referrals.

    Returns:
        {
          "success": True,
          "counts": {
            "total": N, "pending": N, "confirmed": N,
            "completed": N, "unconfirmed": N
          },
          "recent": [
            {
              "referral_id": ..., "patient_name": ...,
              "specialist_needed": ..., "urgency": ...,
              "status": ..., "created_at": ...
            },
            ...
          ]
        }
    """
    db = get_db_session()
    try:
        # --- Counts by status ---
        total       = db.query(Referral).count()
        pending     = db.query(Referral).filter_by(status="pending").count()
        confirmed   = db.query(Referral).filter_by(status="confirmed").count()
        completed   = db.query(Referral).filter_by(status="completed").count()
        unconfirmed = db.query(Referral).filter_by(status="unconfirmed").count()

        # --- Last 10 referrals (newest first) ---
        recent_referrals = (
            db.query(Referral)
            .order_by(Referral.created_at.desc())
            .limit(10)
            .all()
        )

        # Build a patient lookup to avoid N+1 queries
        patient_ids = list({r.patient_id for r in recent_referrals})
        patients = db.query(Patient).filter(Patient.id.in_(patient_ids)).all()
        patient_map = {p.id: p.name for p in patients}

        recent = [
            {
                "referral_id":      r.id,
                "patient_name":     patient_map.get(r.patient_id, "Unknown"),
                "specialist_needed": r.specialist_needed,
                "urgency":          r.urgency,
                "status":           r.status,
                "created_at":       r.created_at.isoformat() if r.created_at else None
            }
            for r in recent_referrals
        ]

        return {
            "success": True,
            "counts": {
                "total":       total,
                "pending":     pending,
                "confirmed":   confirmed,
                "completed":   completed,
                "unconfirmed": unconfirmed
            },
            "recent": recent
        }

    except Exception as e:
        return {"success": False, "error": str(e)}
    finally:
        db.close()
