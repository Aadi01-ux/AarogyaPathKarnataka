"""
multilingual_agent.py — Multilingual Assistance Agent

Thin wrapper around utils.translate(). Called by the Orchestrator when
a staff member wants to translate care instructions for a patient.

Entry point: translate_text(text, target_language) -> dict
"""

import sys
import os
from datetime import datetime

# Ensure backend/ is on the path
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from config import get_db_session
from models.db_models import AgentLog
from utils import translate


def translate_text(text: str, target_language: str) -> dict:
    """
    Translate text using IBM Granite and log the action.

    Args:
        text:            The text to translate.
        target_language: 'en' (English) or 'kn' (Kannada).

    Returns:
        {"success": True,  "translated_text": "...", "language": "kn"}
        {"success": False, "error": "..."}
    """
    db = get_db_session()
    try:
        # Delegate translation to utils.translate()
        result = translate(text, target_language)

        # Log the action (not tied to a specific referral)
        log = AgentLog(
            referral_id=None,
            agent_name="MultilingualAgent",
            action_taken=(
                f"Translated text to '{target_language}'. "
                f"Input length: {len(text)} chars."
            ),
            timestamp=datetime.utcnow()
        )
        db.add(log)
        db.commit()

        return {
            "success":         True,
            "translated_text": result,
            "language":        target_language
        }

    except ValueError as ve:
        # Unsupported language code — user error, don't log as system error
        return {"success": False, "error": str(ve)}
    except Exception as e:
        db.rollback()
        return {"success": False, "error": str(e)}
    finally:
        db.close()
