# Aarogya Path Karnataka — Development Plan

## Top-Level Overview

**Project:** Aarogya Path Karnataka – Rural Healthcare Referral & Follow-up Coordination Agent  
**Hackathon:** IBM Bob Hackathon  
**Goal:** Build a multi-agent AI system that simplifies healthcare coordination for rural patients in Karnataka — covering specialist referrals, lab tests, hospital visits, multilingual instructions, appointment reminders, and status tracking.

**Scope:**
- Six AI agents, each with a single clear responsibility
- Python/Flask backend
- Plain HTML/CSS/JavaScript frontend
- MySQL database (local)
- IBM Granite LLM via watsonx.ai API
- Synthetic patient data only — no real patient records, no clinical decisions

**Approach:**
- Central Orchestrator routes all requests to the correct agent (no agent-to-agent direct calls)
- One shared watsonx client wraps all IBM Granite calls
- Each phase is independently buildable and testable
- Code is kept simple and readable for beginners

**Non-Goals:**
- Disease diagnosis or clinical decision-making
- Modifying medical instructions
- Real patient data
- IBM Cloud hosting (deferred — local MySQL for demo)

---

## Architecture Summary

### Three-Tier Layout

```
Frontend (Browser)          — HTML + CSS + JavaScript
        |  HTTP REST API
Backend (Python/Flask)      — Orchestrator + 6 Agents + watsonx Client
        |  SQL queries
Database (MySQL)            — 6 tables for patients, referrals, appointments, tasks, reminders, logs
```

### Agent Responsibilities

| Agent | Responsibility |
|---|---|
| Referral Processing Agent | Extracts referral details from uploaded document text using Granite |
| Care Journey Agent | Builds a timeline of hospital visits, lab tests, and administrative tasks |
| Multilingual Assistance Agent | Translates and explains instructions in Kannada and English using Granite |
| Reminder Agent | Generates appointment reminders only after patient consent is confirmed |
| Status Tracking Agent | Reads the DB and reports pending, completed, and unconfirmed referrals |
| Dashboard Agent | Aggregates all referral and task data for the dashboard view |

### Communication Pattern

All agents are called only by the Orchestrator. The frontend talks only to Flask REST endpoints. Agents never call each other directly. Shared logic (such as translation) lives in `utils.py` and is imported directly by any agent that needs it.

```
Frontend → Flask API Route → Orchestrator → Agent → watsonx Client (Granite)
                                         → Agent → MySQL Database
                                         → Agent → utils.py (shared translate, helpers)
```

---

## Folder Structure

```
AarogyaPathKarnataka/
├── backend/
│   ├── app.py                        ← Flask app entry point
│   ├── config.py                     ← Environment variables and DB settings
│   ├── watsonx_client.py             ← Shared IBM Granite API wrapper
│   ├── orchestrator.py               ← Routes requests to the right agent
│   ├── auth.py                       ← Staff login, session management, login_required decorator
│   ├── utils.py                      ← Shared utility functions (translate, parse_json_response, etc.)
│   ├── seed_data.py                  ← Loads synthetic patient and referral data
│   ├── agents/
│   │   ├── __init__.py
│   │   ├── referral_processing_agent.py
│   │   ├── care_journey_agent.py
│   │   ├── multilingual_agent.py
│   │   ├── reminder_agent.py
│   │   ├── status_tracking_agent.py
│   │   └── dashboard_agent.py
│   ├── models/
│   │   ├── __init__.py
│   │   └── db_models.py              ← SQLAlchemy ORM models (includes staff_users table)
│   └── routes/
│       ├── __init__.py
│       ├── api_routes.py             ← All REST API endpoints (protected by login_required)
│       └── auth_routes.py            ← Login and logout endpoints
├── frontend/
│   ├── index.html                    ← Single-page app shell (shows login if not authenticated)
│   ├── login.html                    ← Staff login page
│   ├── css/
│   │   └── style.css
│   └── js/
│       ├── app.js                    ← Page routing, shared apiFetch(), auth guard
│       ├── dashboard.js              ← Dashboard view logic
│       ├── referral.js               ← Referral upload and status
│       └── reminders.js              ← Reminder management with consent checkbox
├── .env                              ← API keys and DB credentials (never committed)
├── .gitignore
├── requirements.txt
└── README.md
```

---

## Database Design

### Tables

**staff_users**
| Column | Type | Notes |
|---|---|---|
| id | INT PK | Auto-increment |
| username | VARCHAR | Unique login name |
| password_hash | VARCHAR | Bcrypt hash — never store plain text |
| full_name | VARCHAR | Display name |
| role | VARCHAR | 'admin' or 'coordinator' |
| created_at | DATETIME | |

**patients**
| Column | Type | Notes |
|---|---|---|
| id | INT PK | Auto-increment |
| name | VARCHAR | Synthetic name |
| village | VARCHAR | Village or taluk |
| phone | VARCHAR | Synthetic phone |
| language_pref | VARCHAR | 'en' or 'kn' |
| consent_on_file | BOOLEAN | Whether patient has given general consent |
| created_at | DATETIME | |

**referrals**
| Column | Type | Notes |
|---|---|---|
| id | INT PK | |
| patient_id | INT FK | → patients.id |
| referring_doctor | VARCHAR | |
| specialist_needed | VARCHAR | |
| urgency | VARCHAR | 'high', 'medium', 'low' |
| status | VARCHAR | 'pending', 'confirmed', 'completed', 'unconfirmed' |
| raw_document_text | TEXT | Original uploaded text |
| extracted_data | JSON | Parsed fields from Granite |
| created_at | DATETIME | |

**appointments**
| Column | Type | Notes |
|---|---|---|
| id | INT PK | |
| referral_id | INT FK | → referrals.id |
| type | VARCHAR | 'specialist_visit', 'lab_test', 'follow_up' |
| location | VARCHAR | Hospital or lab name |
| scheduled_at | DATETIME | |
| status | VARCHAR | 'pending', 'completed', 'cancelled' |

**tasks**
| Column | Type | Notes |
|---|---|---|
| id | INT PK | |
| referral_id | INT FK | → referrals.id |
| description | TEXT | Administrative task description |
| completed | BOOLEAN | Default FALSE |
| created_at | DATETIME | |

**reminders**
| Column | Type | Notes |
|---|---|---|
| id | INT PK | |
| referral_id | INT FK | → referrals.id |
| message_en | TEXT | English reminder text |
| message_kn | TEXT | Kannada reminder text |
| consent_given | BOOLEAN | Must be TRUE before sending |
| sent_at | DATETIME | NULL until dispatched |

**agent_logs**
| Column | Type | Notes |
|---|---|---|
| id | INT PK | |
| referral_id | INT FK | → referrals.id |
| agent_name | VARCHAR | Which agent acted |
| action_taken | TEXT | Description of what was done |
| timestamp | DATETIME | |

---

## REST API Endpoints

All `/api/*` routes except `/api/auth/login` require the staff member to be logged in (session cookie). Unauthenticated requests receive HTTP 401.

| Method | Endpoint | Auth Required | Agent Triggered | Description |
|---|---|---|---|---|
| POST | /api/auth/login | No | — | Staff login, sets session cookie |
| POST | /api/auth/logout | Yes | — | Staff logout, clears session |
| POST | /api/referral/upload | Yes | Referral Processing | Upload document text, extract referral |
| GET | /api/referral/{id} | Yes | Status Tracking | Get referral details and current status |
| GET | /api/referral/{id}/journey | Yes | Care Journey | Get full care timeline for a referral |
| POST | /api/referral/{id}/translate | Yes | Multilingual | Translate instructions to patient's language |
| POST | /api/referral/{id}/reminder | Yes | Reminder | Generate and store a reminder |
| GET | /api/dashboard | Yes | Dashboard | Get all referrals summary for dashboard |
| GET | /api/patients | Yes | — | List all synthetic patients |
| POST | /api/seed | Yes | — | Load synthetic seed data |

---

## IBM Granite Integration

- **Module:** `backend/watsonx_client.py`
- **Model:** `ibm/granite-13b-instruct-v2` (configurable via `.env`)
- **Auth:** IBM Cloud IAM API key + watsonx.ai project ID, loaded from `.env`
- **Pattern:** Each agent builds a task-specific prompt string, calls `watsonx_client.generate(prompt)`, and parses the response text
- **Prompt templates** are defined inside each agent file — no prompt logic lives in the shared client

---

## Sub-Tasks

---

### Phase 1 — Project Scaffold

**Intent:** Set up the complete folder structure, Flask app skeleton, MySQL database schema, Python dependencies, and environment configuration. This is the foundation every other phase builds on.

**Expected Outcomes:**
- All folders and placeholder files exist
- Flask app starts without errors and responds to a health-check route `/api/health`
- MySQL database exists with all six tables created
- `.env` file template is documented in README
- `requirements.txt` lists all dependencies

**Todo List:**
- [ ] Create folder structure as defined in the Folder Structure section above
- [ ] Create `requirements.txt` with Flask, SQLAlchemy, PyMySQL, python-dotenv, requests, flask-cors, bcrypt, flask-session
- [ ] Create `.env` template with placeholders for WATSONX_API_KEY, WATSONX_PROJECT_ID, WATSONX_URL, DB_HOST, DB_PORT, DB_USER, DB_PASSWORD, DB_NAME, SECRET_KEY
- [ ] Create `backend/config.py` to load all env vars including SECRET_KEY for Flask sessions
- [ ] Create `backend/app.py` as a minimal Flask app with `/api/health` endpoint and session configuration
- [ ] Create `backend/models/db_models.py` with all seven SQLAlchemy models (including staff_users)
- [ ] Write MySQL `CREATE TABLE` statements and run them against local MySQL
- [ ] Create `.gitignore` to exclude `.env`, `__pycache__`, `*.pyc`
- [ ] Create `README.md` with setup instructions

**Relevant Context:**
- All seven table definitions are in the Database Design section above
- Use `flask-cors` to allow the frontend (served from a different port) to call the backend
- Use `python-dotenv` to load `.env` automatically when Flask starts
- `SECRET_KEY` in `.env` is used by Flask to sign session cookies — keep it long and random

**Status:** `[x] complete`

---

### Phase 1b — Staff Authentication ✓ COMPLETE

**Intent:** Add a simple session-based login system so only authorized healthcare staff can access the application. This protects patient data from unauthorized access.

**Expected Outcomes:**
- POST `/api/auth/login` accepts `username` + `password`, verifies against the `staff_users` table, and sets a session cookie
- POST `/api/auth/logout` clears the session
- A `login_required` decorator in `backend/auth.py` protects all API routes — returns HTTP 401 if not logged in
- The frontend redirects to `login.html` if the session check fails
- Two default staff accounts exist in seed data: one admin and one coordinator (both with synthetic credentials)

**Todo List:**
- [ ] Add `staff_users` table model to `backend/models/db_models.py`
- [ ] Create `backend/auth.py` with a `login_required` decorator that checks Flask session
- [ ] Create `backend/routes/auth_routes.py` with POST `/api/auth/login` and POST `/api/auth/logout`
- [ ] Hash passwords with bcrypt — never store or log plain text passwords
- [ ] Create `frontend/login.html` with a simple username/password form
- [ ] Add session check in `frontend/js/app.js`: if not logged in, redirect to `login.html`
- [ ] Apply `@login_required` to all routes in `backend/routes/api_routes.py`
- [ ] Add two synthetic staff users (admin + coordinator) to `seed_data.py`
- [ ] Test: unauthenticated API calls return 401, login succeeds with correct credentials

**Relevant Context:**
- Use Flask's built-in session (cookie-based) — no JWT needed for this beginner-friendly app
- The `login_required` decorator checks `session.get('staff_user_id')` — if absent, return `{"success": false, "error": "Unauthorized"}` with HTTP 401
- Default synthetic credentials must be documented in README (e.g. admin/Admin@1234) and changed before any real deployment

**Status:** `[x] complete`

---

### Phase 2 — IBM Granite Integration ✓ COMPLETE

**Intent:** Build and test the shared `watsonx_client.py` module so all agents can call IBM Granite reliably. Validate the connection with a simple test prompt before building any agent.

**Expected Outcomes:**
- `watsonx_client.py` successfully authenticates with watsonx.ai using the IAM API key
- A test script can send a prompt and print the Granite response
- The module handles HTTP errors gracefully and returns a plain error string rather than crashing

**Todo List:**
- [ ] Research the watsonx.ai REST API endpoint for text generation (`/ml/v1/text/generation`)
- [ ] Implement `watsonx_client.py` with a single public function `generate(prompt: str) -> str`
- [ ] Add IAM token fetching logic (POST to `https://iam.cloud.ibm.com/identity/token`)
- [ ] Cache the IAM token and refresh it when it expires
- [ ] Write a standalone test script `backend/test_watsonx.py` that sends "Hello, respond in one sentence." and prints the result
- [ ] Document the required `.env` keys in README

**Relevant Context:**
- Credentials are in `.env`: WATSONX_API_KEY, WATSONX_PROJECT_ID, WATSONX_URL
- The watsonx.ai generation endpoint requires the project_id in the request body
- Token caching avoids a new IAM call on every agent invocation

**Status:** `[x] complete`

---

### Phase 3 — Database Layer and Seed Data ✓ COMPLETE

**Intent:** Implement the SQLAlchemy ORM models in full and populate the database with synthetic patients and referrals so all subsequent agents have realistic data to work with during development and demo.

**Expected Outcomes:**
- All six ORM models are defined and map correctly to the MySQL tables
- Running `seed_data.py` inserts at least 10 synthetic patients, 15 referrals in various statuses, and matching appointments and tasks
- Data can be queried through SQLAlchemy sessions in agent code

**Todo List:**
- [ ] Complete `backend/models/db_models.py` with all seven SQLAlchemy model classes
- [ ] Add a `get_db_session()` helper in `backend/config.py`
- [ ] Write `backend/seed_data.py` with 10 synthetic Karnataka patients (fictional names, villages, phone numbers)
- [ ] Add 15 synthetic referrals covering all four statuses: pending, confirmed, completed, unconfirmed
- [ ] Add synthetic appointments and tasks linked to those referrals
- [ ] Add two synthetic staff users (admin + coordinator) with bcrypt-hashed passwords
- [ ] Verify seed data loads cleanly by querying patient count from a Python shell

**Relevant Context:**
- Synthetic data must be clearly fictional — use names like "Ravi Kumar (Synthetic)" or village names from Karnataka geography
- Do not use real doctor names or hospital names — use "Dr. Test Physician" style placeholders or generic names
- Language preference in patients table drives Multilingual Agent behavior
- `consent_on_file` in the patients table is the master consent flag; the `consent_given` field on individual reminders is the per-action consent

**Status:** `[x] complete`

---

### Phase 4 — Referral Processing Agent ✓ COMPLETE

**Intent:** Build the first and most critical agent. It receives raw document text (simulating a scanned referral letter), sends it to IBM Granite, and extracts structured fields — patient name, referring doctor, specialist needed, urgency — then saves the referral to the database.

**Expected Outcomes:**
- POST `/api/referral/upload` accepts a JSON body with `patient_id` and `document_text`
- Granite extracts: referring_doctor, specialist_needed, urgency, and any notes
- Extracted data is saved to the `referrals` table with status = 'pending'
- An entry is written to `agent_logs`
- API returns the created referral ID and extracted fields

**Todo List:**
- [ ] Write `backend/agents/referral_processing_agent.py` with a `process(patient_id, document_text)` function
- [ ] Validate inputs before calling Granite: `patient_id` must exist in DB, `document_text` must be non-empty and under 5000 characters
- [ ] Design the extraction prompt: instruct Granite to return JSON with the four fields
- [ ] Parse Granite's text response and extract the JSON (handle cases where Granite wraps it in prose)
- [ ] Validate extracted fields: urgency must be one of 'high', 'medium', 'low'; fallback to 'medium' if unrecognized
- [ ] Save the referral record to MySQL via SQLAlchemy
- [ ] Log the action to `agent_logs`
- [ ] Add the POST `/api/referral/upload` route to `backend/routes/api_routes.py` with `@login_required`
- [ ] Wire the route through `backend/orchestrator.py` to the agent
- [ ] Test with a sample referral letter text

**Relevant Context:**
- Prompt engineering tip: ask Granite to respond ONLY with JSON and no additional text, to make parsing reliable
- If Granite's response cannot be parsed as JSON, store the raw text in `extracted_data` and flag the referral for manual review
- Input validation happens in the route handler before calling the Orchestrator — keep agent code clean
- The route is registered in `app.py` via Flask Blueprints

**Status:** `[x] complete`

---

### Phase 5 — Care Journey Agent and Status Tracking Agent ✓ COMPLETE

**Intent:** Build two agents together because they both read the same referral data. The Care Journey Agent uses Granite to generate a logical sequence of steps for a referral (visit specialist → get lab test → collect report → follow-up). The Status Tracking Agent reads the database and reports the current state of all referrals.

**Expected Outcomes:**
- GET `/api/referral/{id}/journey` returns a structured timeline of steps with descriptions
- GET `/api/referral/{id}` returns full referral details including current status and all appointments/tasks
- Both agents write their actions to `agent_logs`
- Appointments generated by Care Journey Agent are saved to the `appointments` table
- Tasks generated are saved to the `tasks` table

**Todo List:**
- [ ] Write `backend/agents/care_journey_agent.py` with a `build_journey(referral_id)` function
- [ ] Design the journey prompt: given specialist type and urgency, ask Granite to list logical care steps
- [ ] Parse the steps and save them as appointments and tasks in the DB
- [ ] Write `backend/agents/status_tracking_agent.py` with a `get_status(referral_id)` function
- [ ] Status agent reads referral, appointments, and tasks from DB — no Granite call needed here
- [ ] Add GET `/api/referral/{id}/journey` and GET `/api/referral/{id}` routes
- [ ] Wire both routes through Orchestrator to their agents
- [ ] Test with a seeded referral

**Relevant Context:**
- Care Journey Agent is the only agent that creates appointments and tasks
- Status Tracking Agent is intentionally a pure DB reader — keeping it simple and fast
- Journey steps should include a human-readable description suitable for display to rural patients

**Status:** `[x] complete`

---

### Phase 6 — Multilingual Assistance Agent and Reminder Agent ✓ COMPLETE

**Intent:** Build the two patient-facing agents. The Multilingual Agent uses Granite to translate care instructions into Kannada or English based on the patient's language preference. The Reminder Agent generates a friendly reminder message in both languages, but only after consent is confirmed.

**Expected Outcomes:**
- POST `/api/referral/{id}/translate` returns instructions in the patient's preferred language
- POST `/api/referral/{id}/reminder` creates a reminder only if `consent_given` is TRUE in the request
- Reminder messages are saved to the `reminders` table in both English and Kannada
- If consent is not given, the API returns a message asking for consent — no reminder is saved
- Both agents log to `agent_logs`

**Todo List:**
- [ ] Add `translate(text, target_language)` to `backend/utils.py`; validate `target_language` is 'en' or 'kn'
- [ ] Design the translation prompt inside `utils.py`: ask Granite to translate text to Kannada or English
- [ ] Write `backend/agents/multilingual_agent.py` — imports `translate` from `utils.py`, passes it through the Orchestrator
- [ ] Write `backend/agents/reminder_agent.py` with a `generate_reminder(referral_id, consent_given)` function — imports `translate` from `utils.py`
- [ ] Check `patients.consent_on_file` before generating — if FALSE, return an error instructing staff to obtain consent first
- [ ] Reminder agent fetches the next upcoming appointment for the referral and builds reminder text
- [ ] Call `utils.translate()` to produce both English and Kannada versions of the reminder
- [ ] Save to `reminders` table only when consent_given is TRUE in the request AND consent_on_file is TRUE in the DB
- [ ] Add POST `/api/referral/{id}/translate` and POST `/api/referral/{id}/reminder` routes with `@login_required`
- [ ] Wire through Orchestrator
- [ ] Test translation with a sample instruction text

**Relevant Context:**
- Both Reminder Agent and Multilingual Agent import `translate()` from `backend/utils.py` — agents do not call each other
- Two-layer consent: `consent_on_file` (patient's standing consent in DB) AND `consent_given` (staff confirms for this specific action in the API request) — both must be TRUE
- Kannada Unicode must render correctly in the JSON response and in the frontend

**Status:** `[x] complete`

---

### Phase 7 — Dashboard Agent and Complete API ✓ COMPLETE

**Intent:** Build the Dashboard Agent that aggregates all referral data into a summary suitable for the frontend dashboard. Also complete and test all API routes end-to-end before building the frontend.

**Expected Outcomes:**
- GET `/api/dashboard` returns counts: total referrals, pending, confirmed, completed, unconfirmed
- Dashboard response also includes a list of recent referrals with patient name, specialist, urgency, and status
- GET `/api/patients` returns all synthetic patients for the referral upload form
- All eight API endpoints return correct JSON and can be tested with a browser or curl
- Orchestrator correctly routes every endpoint

**Todo List:**
- [ ] Write `backend/agents/dashboard_agent.py` with a `get_summary()` function
- [ ] Dashboard agent queries the DB for counts and recent referrals — no Granite call needed
- [ ] Complete `backend/routes/api_routes.py` with all eight endpoints
- [ ] Complete `backend/orchestrator.py` to route all eight endpoints to the right agent/function
- [ ] Register the Blueprint in `backend/app.py`
- [ ] Test all endpoints manually using curl or a REST client
- [ ] Verify agent_logs table is being populated by all agents

**Relevant Context:**
- Dashboard Agent is intentionally a pure DB reader like Status Tracking Agent
- The dashboard data shape must match what `frontend/js/dashboard.js` will consume — keep field names consistent
- All routes return JSON with a consistent envelope: `{"success": true, "data": {...}}` or `{"success": false, "error": "..."}`

**Status:** `[x] complete`

---

### Phase 8 — Frontend ✓ COMPLETE

**Intent:** Build the complete plain HTML/CSS/JavaScript frontend. It has four views: Dashboard, Referral Upload, Referral Detail (with journey and reminders), and Patient List. No framework — just vanilla JS fetching from the Flask API.

**Expected Outcomes:**
- `index.html` loads and shows the Dashboard view by default
- Dashboard view displays referral counts and a table of recent referrals
- Referral Upload form lets the user select a patient and paste document text, then calls the API
- Referral Detail view shows the care journey timeline, current status, and a reminder button
- Reminder button shows a consent checkbox — reminder is only sent when consent is checked
- Language toggle switches all instruction text between English and Kannada
- The app works correctly when Flask serves the frontend as static files

**Todo List:**
- [ ] Create `frontend/login.html` with a username/password form that POSTs to `/api/auth/login`
- [ ] Create `frontend/index.html` with navigation tabs for Dashboard, Upload Referral, and Patients
- [ ] Create `frontend/css/style.css` with clean, minimal styling suitable for a healthcare app
- [ ] Create `frontend/js/app.js` with a simple tab-switching router, a shared `apiFetch()` helper, and an auth guard that redirects to `login.html` on HTTP 401
- [ ] Create `frontend/js/dashboard.js` to fetch `/api/dashboard` and render counts and referral table
- [ ] Create `frontend/js/referral.js` to handle the upload form (with client-side validation) and referral detail view
- [ ] Create `frontend/js/reminders.js` to handle the two-step consent flow: show consent checkbox, only enable the Send Reminder button when checked
- [ ] Add a Kannada/English language toggle that calls `/api/referral/{id}/translate` for instructions
- [ ] Configure Flask to serve the `frontend/` folder as static files
- [ ] Do a full end-to-end test: log in, upload a referral, view the journey, generate a reminder, log out

**Relevant Context:**
- Flask can serve static files from a folder using `send_from_directory` for `index.html` and static assets
- The `apiFetch()` helper in `app.js` should handle the base URL so individual JS files do not hardcode it and should automatically redirect to `login.html` on a 401 response
- All text visible to rural patients should be simple and clear — avoid medical jargon in the UI
- Client-side validation on the upload form: patient must be selected, document text must not be empty

**Status:** `[x] complete`

---

## Input Validation Rules

Apply these rules in the route handlers before calling any agent:

| Field | Rule |
|---|---|
| `patient_id` | Must be a positive integer; must exist in the `patients` table |
| `document_text` | Must be a non-empty string; maximum 5000 characters |
| `referral_id` (URL param) | Must be a positive integer; must exist in the `referrals` table |
| `target_language` | Must be exactly `'en'` or `'kn'` |
| `consent_given` (reminder) | Must be boolean TRUE — if FALSE or missing, return 400 with a consent-required message |
| `username` / `password` (login) | Both required; non-empty strings; never logged |

All validation failures return HTTP 400 with `{"success": false, "error": "<reason>"}`.

---

## Implementation Notes for Beginners

1. **Work one phase at a time.** Do not start Phase 2 until Phase 1 is working.
2. **Test each agent independently** before wiring it to the API route.
3. **Print Granite's raw response** during development so you can see what the model returns before trying to parse it.
4. **Keep prompts simple.** Shorter, clearer prompts work better than long complex ones.
5. **Never commit `.env`** — it contains your API key and database password. The `.gitignore` file will protect this.
6. **Use synthetic data only.** All patient names, phone numbers, and doctor names must be clearly fictional.
7. **Never log passwords or API keys** — only log actions and referral IDs.

---

## Privacy and Safety Guardrails

- No real patient data at any point
- Agents never output a diagnosis or treatment recommendation
- All `/api/*` routes are protected by staff authentication
- Reminders require two layers of consent: patient's standing consent on file AND staff confirmation per action
- All Granite prompts include the instruction: "Do not provide medical diagnoses or clinical recommendations."
- Passwords are stored as bcrypt hashes — never plain text
- `agent_logs` table provides a full audit trail of every AI action for review
- Sensitive fields (phone numbers) are stored only as synthetic data and never transmitted in logs
