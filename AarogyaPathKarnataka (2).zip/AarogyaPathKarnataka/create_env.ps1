# Creates the .env file with your database credentials
# Run once from any PowerShell window (no Admin needed)

$envPath = "C:\Users\HP\Desktop\AarogyaPathKarnataka\.env"

$content = @(
    "WATSONX_API_KEY=your_watsonx_api_key_here",
    "WATSONX_PROJECT_ID=your_watsonx_project_id_here",
    "WATSONX_URL=https://us-south.ml.cloud.ibm.com",
    "WATSONX_MODEL_ID=ibm/granite-13b-instruct-v2",
    "DB_HOST=localhost",
    "DB_PORT=3306",
    "DB_USER=root",
    "DB_PASSWORD=AarogyaPath@2024",
    "DB_NAME=aarogya_path",
    "SECRET_KEY=AarogyaPath-SecretKey-2024-KarnatakaHealth"
)

$content -join "`n" | Set-Content -Path $envPath -Encoding UTF8
Write-Host ".env file created at $envPath" -ForegroundColor Green
Write-Host "Remember to fill in your WATSONX_API_KEY and WATSONX_PROJECT_ID!" -ForegroundColor Yellow
