/**
 * patient-app.js
 * Patient portal JavaScript — auth guard, API helpers, rendering.
 * Loaded only by patient-portal.html. No dependency on app.js or other staff JS.
 */

const API_BASE = 'http://127.0.0.1:5000';

// ---------------------------------------------------------------------------
// i18n — UI label translations
// ---------------------------------------------------------------------------
const LABELS = {
  en: {
    greeting:          'Hello',
    tabReferrals:      'Referrals',
    tabAppointments:   'Appointments',
    tabReminders:      'Reminders',
    tabJourney:        'My Journey',
    sectionReferrals:  'My Referrals',
    sectionAppts:      'Upcoming Appointments',
    sectionReminders:  'Reminders & Instructions',
    sectionJourney:    'Care Journey',
    noReferrals:       'No referrals found.',
    noAppts:           'No upcoming appointments.',
    noReminders:       'No reminders yet.',
    noJourney:         'No care journey details yet.',
    loading:           'Loading…',
    logout:            'Logout',
    back:              '← Back',
    status:            'Status',
    urgency:           'Urgency',
    specialist:        'Specialist',
    doctor:            'Referred by',
    date:              'Date',
    location:          'Location',
    type:              'Type',
    followUp:          'Follow-up Instructions',
    viewDetails:       'View Details →',
    apptTypes: {
      specialist_visit: 'Specialist Visit',
      lab_test:         'Lab Test',
      follow_up:        'Follow-up'
    },
    statusLabels: {
      pending:     'Pending',
      confirmed:   'Confirmed',
      completed:   'Completed',
      unconfirmed: 'Unconfirmed'
    }
  },
  kn: {
    greeting:          'ನಮಸ್ಕಾರ',
    tabReferrals:      'ರೆಫರಲ್',
    tabAppointments:   'ಅಪಾಯಿಂಟ್ಮೆಂಟ್',
    tabReminders:      'ರಿಮೈಂಡರ್',
    tabJourney:        'ನನ್ನ ಪ್ರಯಾಣ',
    sectionReferrals:  'ನನ್ನ ರೆಫರಲ್‌ಗಳು',
    sectionAppts:      'ಮುಂಬರುವ ಅಪಾಯಿಂಟ್ಮೆಂಟ್‌ಗಳು',
    sectionReminders:  'ರಿಮೈಂಡರ್‌ಗಳು ಮತ್ತು ಸೂಚನೆಗಳು',
    sectionJourney:    'ಆರೈಕೆ ಪ್ರಯಾಣ',
    noReferrals:       'ಯಾವುದೇ ರೆಫರಲ್ ಕಂಡುಬಂದಿಲ್ಲ.',
    noAppts:           'ಮುಂಬರುವ ಯಾವುದೇ ಅಪಾಯಿಂಟ್ಮೆಂಟ್ ಇಲ್ಲ.',
    noReminders:       'ಇನ್ನೂ ಯಾವುದೇ ರಿಮೈಂಡರ್ ಇಲ್ಲ.',
    noJourney:         'ಇನ್ನೂ ಆರೈಕೆ ಪ್ರಯಾಣ ವಿವರಗಳಿಲ್ಲ.',
    loading:           'ಲೋಡ್ ಆಗುತ್ತಿದೆ…',
    logout:            'ಲಾಗ್ ಔಟ್',
    back:              '← ಹಿಂದೆ',
    status:            'ಸ್ಥಿತಿ',
    urgency:           'ತುರ್ತು',
    specialist:        'ತಜ್ಞ',
    doctor:            'ರೆಫರ್ ಮಾಡಿದವರು',
    date:              'ದಿನಾಂಕ',
    location:          'ಸ್ಥಳ',
    type:              'ವಿಧ',
    followUp:          'ಅನುಸರಣಾ ಸೂಚನೆಗಳು',
    viewDetails:       'ವಿವರಗಳು →',
    apptTypes: {
      specialist_visit: 'ತಜ್ಞ ಭೇಟಿ',
      lab_test:         'ಲ್ಯಾಬ್ ಟೆಸ್ಟ್',
      follow_up:        'ಅನುಸರಣಾ'
    },
    statusLabels: {
      pending:     'ಬಾಕಿ ಇದೆ',
      confirmed:   'ದೃಢೀಕರಿಸಲಾಗಿದೆ',
      completed:   'ಪೂರ್ಣಗೊಂಡಿದೆ',
      unconfirmed: 'ಅನಿಶ್ಚಿತ'
    }
  }
};

// ---------------------------------------------------------------------------
// Application state
// ---------------------------------------------------------------------------
let currentLang = 'en';
let currentPatient = null;   // { patient_name, language }
let activeTab = 'referrals';
let detailReferralId = null;  // set when viewing detail

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------
function L(key) {
  const parts = key.split('.');
  let obj = LABELS[currentLang] || LABELS.en;
  for (const p of parts) {
    obj = obj?.[p];
    if (obj === undefined) break;
  }
  return obj || key;
}

async function apiFetch(path, options = {}) {
  const defaults = { credentials: 'include', headers: { 'Content-Type': 'application/json' } };
  const resp = await fetch(API_BASE + path, { ...defaults, ...options });
  return resp.json();
}

function statusBadge(status) {
  const cls = 'badge-' + (status || 'pending');
  const label = L('statusLabels.' + status) || status || '—';
  return `<span class="p-badge ${cls}">${label}</span>`;
}

function urgencyBadge(urgency) {
  const cls = 'badge-' + (urgency || 'low');
  return `<span class="p-badge ${cls}">${(urgency || '—').toUpperCase()}</span>`;
}

function formatDate(isoString) {
  if (!isoString) return '—';
  try {
    const d = new Date(isoString);
    return d.toLocaleDateString(currentLang === 'kn' ? 'kn-IN' : 'en-IN', {
      day: 'numeric', month: 'short', year: 'numeric'
    });
  } catch { return isoString; }
}

function formatDateTime(isoString) {
  if (!isoString) return '—';
  try {
    const d = new Date(isoString);
    return d.toLocaleString(currentLang === 'kn' ? 'kn-IN' : 'en-IN', {
      day: 'numeric', month: 'short', year: 'numeric',
      hour: '2-digit', minute: '2-digit'
    });
  } catch { return isoString; }
}

// ---------------------------------------------------------------------------
// Auth guard — redirect to /patient-login if no session
// ---------------------------------------------------------------------------
async function checkPatientAuth() {
  try {
    const data = await apiFetch('/api/patient/auth/me');
    if (data.success) {
      currentPatient = data.data;
      currentLang = currentPatient.language || 'en';
      return true;
    }
  } catch { /* network error */ }
  window.location.href = '/patient-login';
  return false;
}

// ---------------------------------------------------------------------------
// Language toggle
// ---------------------------------------------------------------------------
function setLanguage(lang) {
  currentLang = lang;
  // Persist to server (fire-and-forget)
  apiFetch('/api/patient/language', {
    method: 'POST',
    body: JSON.stringify({ language: lang })
  }).catch(() => {});

  // Update toggle button states
  document.querySelectorAll('.lang-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.lang === lang);
  });

  // Re-render all visible UI labels
  refreshAllLabels();
  reloadCurrentTab();
}

function refreshAllLabels() {
  document.querySelectorAll('[data-label]').forEach(el => {
    el.textContent = L(el.dataset.label);
  });
  if (currentPatient) {
    document.getElementById('greetingName').textContent =
      L('greeting') + ', ' + currentPatient.patient_name;
  }
  document.getElementById('btnLogout').textContent = L('logout');
}

// ---------------------------------------------------------------------------
// Tab navigation
// ---------------------------------------------------------------------------
function switchTab(tab) {
  activeTab = tab;
  detailReferralId = null;

  document.querySelectorAll('.p-nav-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.tab === tab);
  });

  document.querySelectorAll('.tab-pane').forEach(p => { p.style.display = 'none'; });
  const pane = document.getElementById('tab-' + tab);
  if (pane) pane.style.display = 'block';

  reloadCurrentTab();
}

function reloadCurrentTab() {
  if (activeTab === 'referrals')     loadReferrals();
  if (activeTab === 'appointments')  loadAppointments();
  if (activeTab === 'reminders')     loadRemindersAll();
  if (activeTab === 'journey')       showJourneyPrompt();
}

// ---------------------------------------------------------------------------
// TAB: Referrals list
// ---------------------------------------------------------------------------
async function loadReferrals() {
  const container = document.getElementById('referrals-content');
  container.innerHTML = `<div class="p-loading">${L('loading')}</div>`;

  try {
    const data = await apiFetch('/api/patient/referrals');
    if (!data.success) throw new Error(data.error);

    const referrals = data.data.referrals;
    if (!referrals.length) {
      container.innerHTML = emptyState('📋', L('noReferrals'));
      return;
    }

    container.innerHTML = referrals.map(r => `
      <div class="p-card">
        <div class="p-card-header">
          <div>
            <div class="p-card-title">${esc(r.specialist_needed || '—')}</div>
            <div class="p-card-sub">${L('doctor')}: ${esc(r.referring_doctor || '—')}</div>
          </div>
          ${statusBadge(r.status)}
        </div>
        <div class="p-card-row">
          <span class="row-icon">⚡</span>
          <span>${L('urgency')}: ${urgencyBadge(r.urgency)}</span>
        </div>
        <div class="p-card-row">
          <span class="row-icon">📅</span>
          <span>${formatDate(r.created_at)}</span>
        </div>
        <button class="pl-btn" style="margin-top:0.75rem;padding:0.6rem;font-size:0.88rem;"
                onclick="viewReferralDetail(${r.id})">
          ${L('viewDetails')}
        </button>
      </div>
    `).join('');

  } catch (err) {
    container.innerHTML = errorMsg(err.message);
  }
}

// ---------------------------------------------------------------------------
// Referral detail view (inline, replaces list)
// ---------------------------------------------------------------------------
async function viewReferralDetail(id) {
  detailReferralId = id;
  const container = document.getElementById('referrals-content');
  container.innerHTML = `<div class="p-loading">${L('loading')}</div>`;

  try {
    const [statusRes, journeyRes, remindersRes] = await Promise.all([
      apiFetch('/api/patient/referral/' + id),
      apiFetch('/api/patient/referral/' + id + '/journey'),
      apiFetch('/api/patient/referral/' + id + '/reminders')
    ]);

    if (!statusRes.success) throw new Error(statusRes.error);
    const ref   = statusRes.data.referral || statusRes.data;
    const appts = statusRes.data.appointments || [];
    const steps = (journeyRes.success && journeyRes.data.steps) ? journeyRes.data.steps : [];
    const rems  = (remindersRes.success && remindersRes.data.reminders) ? remindersRes.data.reminders : [];

    let html = `
      <button class="p-back-btn" onclick="loadReferrals()">${L('back')}</button>
      <div class="p-card">
        <div class="p-card-header">
          <div>
            <div class="p-card-title">${esc(ref.specialist_needed || '—')}</div>
            <div class="p-card-sub">${L('doctor')}: ${esc(ref.referring_doctor || '—')}</div>
          </div>
          ${statusBadge(ref.status)}
        </div>
        <div class="p-card-row"><span class="row-icon">⚡</span>${L('urgency')}: ${urgencyBadge(ref.urgency)}</div>
        <div class="p-card-row"><span class="row-icon">📅</span>${formatDate(ref.created_at)}</div>
      </div>`;

    // Appointments section
    if (appts.length) {
      html += `<div class="p-section-title">${L('sectionAppts')}</div>`;
      html += appts.map(a => `
        <div class="p-card">
          <div class="appt-type-label">${L('apptTypes.' + a.type) || a.type}</div>
          <div class="p-card-row"><span class="row-icon">📍</span>${esc(a.location || '—')}</div>
          <div class="p-card-row"><span class="row-icon">🕐</span>${formatDateTime(a.scheduled_at)}</div>
          ${statusBadge(a.status)}
        </div>`).join('');
    }

    // Care journey
    if (steps.length) {
      html += `<div class="p-section-title">${L('sectionJourney')}</div>
               <div class="p-timeline">`;
      html += steps.map((s, i) => `
        <div class="p-timeline-item">
          <div class="p-timeline-step">${L('type')} ${i + 1}</div>
          <div class="p-timeline-desc">${esc(s.description || s.action || JSON.stringify(s))}</div>
          ${s.date ? `<div class="p-timeline-date">${formatDate(s.date)}</div>` : ''}
        </div>`).join('');
      html += `</div>`;
    }

    // Reminders / follow-up
    if (rems.length) {
      html += `<div class="p-section-title">${L('followUp')}</div>`;
      html += rems.map(r => `
        <div class="p-reminder-msg ${currentLang === 'kn' ? 'kn' : ''}">
          ${esc(r.message || '—')}
        </div>`).join('');
    }

    container.innerHTML = html;

  } catch (err) {
    container.innerHTML = `
      <button class="p-back-btn" onclick="loadReferrals()">${L('back')}</button>
      ${errorMsg(err.message)}`;
  }
}

// ---------------------------------------------------------------------------
// TAB: Appointments
// ---------------------------------------------------------------------------
async function loadAppointments() {
  const container = document.getElementById('appointments-content');
  container.innerHTML = `<div class="p-loading">${L('loading')}</div>`;

  try {
    const data = await apiFetch('/api/patient/appointments');
    if (!data.success) throw new Error(data.error);

    const appts = data.data.appointments;
    if (!appts.length) {
      container.innerHTML = emptyState('📅', L('noAppts'));
      return;
    }

    container.innerHTML = appts.map(a => `
      <div class="p-card">
        <div class="p-card-header">
          <div class="appt-type-label">${L('apptTypes.' + a.type) || a.type}</div>
          ${statusBadge(a.status)}
        </div>
        <div class="p-card-row"><span class="row-icon">📍</span>${esc(a.location || '—')}</div>
        <div class="p-card-row"><span class="row-icon">🕐</span>${formatDateTime(a.scheduled_at)}</div>
      </div>
    `).join('');

  } catch (err) {
    container.innerHTML = errorMsg(err.message);
  }
}

// ---------------------------------------------------------------------------
// TAB: Reminders (across all referrals)
// ---------------------------------------------------------------------------
async function loadRemindersAll() {
  const container = document.getElementById('reminders-content');
  container.innerHTML = `<div class="p-loading">${L('loading')}</div>`;

  try {
    // First get all referral IDs, then fetch reminders for each
    const refData = await apiFetch('/api/patient/referrals');
    if (!refData.success) throw new Error(refData.error);

    const refs = refData.data.referrals;
    if (!refs.length) {
      container.innerHTML = emptyState('🔔', L('noReminders'));
      return;
    }

    const allReminders = [];
    await Promise.all(refs.map(async r => {
      try {
        const rd = await apiFetch('/api/patient/referral/' + r.id + '/reminders');
        if (rd.success && rd.data.reminders.length) {
          rd.data.reminders.forEach(rem => {
            allReminders.push({ ...rem, referralId: r.id, specialist: r.specialist_needed });
          });
        }
      } catch { /* skip failed referral */ }
    }));

    if (!allReminders.length) {
      container.innerHTML = emptyState('🔔', L('noReminders'));
      return;
    }

    container.innerHTML = allReminders.map(r => `
      <div class="p-card">
        <div class="p-card-sub" style="margin-bottom:0.5rem;">
          ${esc(r.specialist || '—')}
        </div>
        <div class="p-reminder-msg ${currentLang === 'kn' ? 'kn' : ''}">
          ${esc(r.message || '—')}
        </div>
        ${r.sent_at ? `<div class="p-card-row" style="margin-top:0.4rem;">
          <span class="row-icon">✅</span>${formatDate(r.sent_at)}
        </div>` : ''}
      </div>
    `).join('');

  } catch (err) {
    container.innerHTML = errorMsg(err.message);
  }
}

// ---------------------------------------------------------------------------
// TAB: Journey — prompt to pick a referral first
// ---------------------------------------------------------------------------
function showJourneyPrompt() {
  const container = document.getElementById('journey-content');
  container.innerHTML = `
    <div class="p-section-title">${L('sectionJourney')}</div>
    <div class="p-card">
      <div class="p-card-sub" style="margin-bottom:0.75rem;">
        ${currentLang === 'kn'
          ? 'ನಿಮ್ಮ ಆರೈಕೆ ಪ್ರಯಾಣ ನೋಡಲು ರೆಫರಲ್ ಟ್ಯಾಬ್‌ನಿಂದ ರೆಫರಲ್ ಆಯ್ಕೆ ಮಾಡಿ.'
          : 'Select a referral from the Referrals tab, then tap "View Details" to see your full care journey and follow-up instructions.'}
      </div>
      <button class="pl-btn" style="padding:0.65rem;font-size:0.9rem;"
              onclick="switchTab('referrals')">
        ${currentLang === 'kn' ? 'ರೆಫರಲ್ ನೋಡಿ →' : 'Go to My Referrals →'}
      </button>
    </div>`;
}

// ---------------------------------------------------------------------------
// Utility renderers
// ---------------------------------------------------------------------------
function emptyState(icon, msg) {
  return `<div class="p-empty"><div class="p-empty-icon">${icon}</div>${esc(msg)}</div>`;
}

function errorMsg(msg) {
  return `<div class="p-error">${esc(msg || 'An error occurred.')}</div>`;
}

function esc(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

// ---------------------------------------------------------------------------
// Logout
// ---------------------------------------------------------------------------
async function patientLogout() {
  try {
    await apiFetch('/api/patient/auth/logout', { method: 'POST' });
  } catch { /* ignore */ }
  window.location.href = '/patient-login';
}

// ---------------------------------------------------------------------------
// Bootstrap — called by patient-portal.html on DOMContentLoaded
// ---------------------------------------------------------------------------
async function initPatientPortal() {
  const authed = await checkPatientAuth();
  if (!authed) return;

  // Update greeting
  document.getElementById('greetingName').textContent =
    L('greeting') + ', ' + currentPatient.patient_name;

  // Set language toggle
  document.querySelectorAll('.lang-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.lang === currentLang);
    btn.addEventListener('click', () => setLanguage(btn.dataset.lang));
  });

  // Logout
  document.getElementById('btnLogout').addEventListener('click', patientLogout);

  // Tab buttons
  document.querySelectorAll('.p-nav-btn').forEach(btn => {
    btn.addEventListener('click', () => switchTab(btn.dataset.tab));
  });

  // Apply all labels
  refreshAllLabels();

  // Load default tab
  switchTab('referrals');
}
