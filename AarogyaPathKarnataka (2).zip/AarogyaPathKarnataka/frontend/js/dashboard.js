/**
 * dashboard.js — Dashboard tab rendering for Aarogya Path Karnataka
 *
 * Loads /api/dashboard and renders:
 *   - 4 stat cards (Total, Pending, Confirmed, Completed)
 *   - Table of recent referrals with View Details action
 *   - Referral detail panel (inline expand) with care journey + reminder section
 */

/**
 * loadDashboard — Fetch dashboard data and render into #tab-dashboard.
 * Called by index.html on initial load and on tab activation.
 */
async function loadDashboard() {
  const container = document.getElementById('tab-dashboard');
  if (!container) return;

  container.innerHTML = '<div class="card"><span class="loading"></span> Loading dashboard...</div>';

  const data = await apiFetch('/api/dashboard');
  if (!data || !data.success) {
    container.innerHTML =
      '<div class="card"><div class="alert alert-error">Failed to load dashboard. ' +
      (data && data.error ? esc(data.error) : '') + '</div></div>';
    return;
  }

  const counts = data.data.counts || {};
  const recent = data.data.recent || [];

  // ---- Build HTML ----
  let html = '';

  // Stat cards row
  html += '<div class="card-row">';
  html += statCard('Total Referrals', counts.total || 0);
  html += statCard('Pending', counts.pending || 0, 'badge-pending');
  html += statCard('Confirmed', counts.confirmed || 0, 'badge-confirmed');
  html += statCard('Completed', counts.completed || 0, 'badge-completed');
  html += '</div>';

  // Recent referrals table
  html += '<div class="card">';
  html += '<h2>Recent Referrals</h2>';

  if (recent.length === 0) {
    html += '<div class="alert alert-info">No referrals found. Upload a referral to get started.</div>';
  } else {
    html += '<table class="data-table"><thead><tr>' +
      '<th>Patient</th><th>Specialist</th><th>Urgency</th>' +
      '<th>Status</th><th>Date</th><th>Action</th>' +
      '</tr></thead><tbody>';

    recent.forEach(r => {
      html += '<tr id="row-' + r.referral_id + '">' +
        '<td>' + esc(r.patient_name) + '</td>' +
        '<td>' + esc(r.specialist_needed) + '</td>' +
        '<td><span class="' + urgencyClass(r.urgency) + '">' + esc(r.urgency) + '</span></td>' +
        '<td>' + badge(r.status) + '</td>' +
        '<td>' + formatDate(r.created_at) + '</td>' +
        '<td><button class="btn btn-secondary btn-sm" ' +
          'onclick="toggleReferralDetail(' + r.referral_id + ')">View Details</button></td>' +
        '</tr>' +
        // Detail row — hidden by default
        '<tr id="detail-row-' + r.referral_id + '" style="display:none;">' +
        '<td colspan="6">' +
        '<div id="detail-' + r.referral_id + '" class="referral-detail">' +
        '<span class="loading"></span> Loading...</div>' +
        '</td></tr>';
    });

    html += '</tbody></table>';
  }

  html += '</div>'; // end .card
  container.innerHTML = html;
}

// ---------------------------------------------------------------------------
// Stat card helper
// ---------------------------------------------------------------------------
function statCard(label, value) {
  return '<div class="stat-card">' +
    '<div class="stat-label">' + esc(label) + '</div>' +
    '<div class="stat-value">' + esc(String(value)) + '</div>' +
    '</div>';
}

// ---------------------------------------------------------------------------
// Referral detail expand/collapse
// ---------------------------------------------------------------------------

/**
 * toggleReferralDetail — Show or hide the detail row for a referral.
 * Always fetches fresh data so journey steps and reminders are up to date.
 */
async function toggleReferralDetail(referralId) {
  const detailRow = document.getElementById('detail-row-' + referralId);
  if (!detailRow) return;

  // Toggle visibility
  if (detailRow.style.display !== 'none') {
    detailRow.style.display = 'none';
    return;
  }
  detailRow.style.display = 'table-row';

  // Reset content so the loading spinner shows on each open
  const container = document.getElementById('detail-' + referralId);
  container.innerHTML = '<span class="loading"></span> Loading...';

  // Fetch referral status
  const data = await apiFetch('/api/referral/' + referralId);

  if (!data || !data.success) {
    container.innerHTML = '<div class="alert alert-error">Failed to load referral details.</div>';
    return;
  }

  const ref   = data.data.referral      || {};
  const appt  = data.data.appointments  || [];
  const tasks = data.data.tasks         || [];

  // Determine if consent is on file (needed for reminder generation)
  // status_tracking_agent returns patient info; check language_pref field presence
  // We fetch patient consent from the patients list cached in the dashboard data
  const hasConsent = ref.consent_on_file !== false; // assume true unless explicitly false

  let html = '<div class="detail-grid">';
  html += detailField('Patient',   ref.patient_name);
  html += detailField('Village',   ref.patient_village);
  html += detailField('Phone',     ref.patient_phone);
  html += detailField('Language',  ref.language_pref === 'kn' ? 'Kannada (ಕನ್ನಡ)' : 'English');
  html += detailField('Doctor',    ref.referring_doctor);
  html += detailField('Specialist',ref.specialist_needed);
  html += detailField('Urgency',   ref.urgency ? '<span class="' + urgencyClass(ref.urgency) + '">' + esc(ref.urgency) + '</span>' : '—', true);
  html += detailField('Status',    badge(ref.status), true);
  html += detailField('Created',   formatDate(ref.created_at));
  html += '</div>';

  // Appointments
  if (appt.length > 0) {
    html += '<h3>Appointments</h3><ul class="timeline">';
    appt.forEach((a, i) => {
      html += '<li>' +
        '<span class="timeline-step">Step ' + (i + 1) + '</span>' +
        '<div><div class="timeline-desc">' + esc(a.type ? a.type.replace(/_/g, ' ') : '') +
        ' — ' + badge(a.status) + '</div>' +
        '<div class="timeline-loc">' + esc(a.location) +
        (a.scheduled_at ? ' &bull; ' + formatDate(a.scheduled_at) : '') + '</div>' +
        '</div></li>';
    });
    html += '</ul>';
  }

  // Tasks
  if (tasks.length > 0) {
    html += '<h3>Tasks</h3><ul style="padding-left:1.2rem;font-size:0.88rem;">';
    tasks.forEach(t => {
      html += '<li style="margin-bottom:0.3rem;">' +
        (t.completed ? '<s>' : '') +
        esc(t.description) +
        (t.completed ? '</s> <span class="badge badge-completed" style="font-size:0.7rem;">Done</span>' : '') +
        '</li>';
    });
    html += '</ul>';
  }

  // Build Care Journey + Generate Reminder buttons
  html += '<div class="flex gap-1 align-center" style="margin-top:1rem;flex-wrap:wrap;">' +
    '<button class="btn btn-primary btn-sm" onclick="loadJourneyInline(' + referralId + ', this)">Build Care Journey</button>' +
    '<button class="btn btn-secondary btn-sm" onclick="showReminderSection(' + referralId + ')">Generate Reminder</button>' +
    '</div>';

  // Consent warning — shown when consent_on_file is explicitly false
  if (ref.consent_on_file === false) {
    html += '<div class="alert alert-warn" style="margin-top:0.6rem;">' +
      '⚠️ Patient consent not on file. Reminder generation will fail until consent is recorded.' +
      '</div>';
  }

  html += '<div id="journey-' + referralId + '" style="margin-top:0.8rem;"></div>';
  html += '<div id="reminder-panel-' + referralId + '" style="margin-top:0.8rem;"></div>';

  container.innerHTML = html;
}

// ---------------------------------------------------------------------------
// Care journey inline loader
// ---------------------------------------------------------------------------

async function loadJourneyInline(referralId, btn) {
  const container = document.getElementById('journey-' + referralId);
  if (!container) return;

  btn.disabled = true;
  btn.textContent = 'Building journey...';
  container.innerHTML = '<span class="loading"></span> Calling IBM Granite...';

  const data = await apiFetch('/api/referral/' + referralId + '/journey');
  btn.disabled = false;
  btn.textContent = 'Rebuild Journey';

  if (!data || !data.success) {
    container.innerHTML = '<div class="alert alert-error">Journey generation failed. ' +
      esc((data && data.error) || '') + '</div>';
    return;
  }

  const steps = (data.data && data.data.steps) || [];
  if (steps.length === 0) {
    container.innerHTML = '<div class="alert alert-info">No steps returned from AI.</div>';
    return;
  }

  let html = '<h3 style="margin-top:0.5rem;">Care Journey Steps</h3><ul class="timeline">';
  steps.forEach(s => {
    html += '<li>' +
      '<span class="timeline-step">Step ' + esc(String(s.step_number)) + '</span>' +
      '<div><div class="timeline-desc">' + esc(s.description) + '</div>' +
      '<div class="timeline-loc">' + esc(s.location) + ' &bull; ' + esc(s.type) + '</div>' +
      '</div></li>';
  });
  html += '</ul>';
  container.innerHTML = html;
}

// ---------------------------------------------------------------------------
// Detail field helper
// ---------------------------------------------------------------------------

/**
 * detailField — render a label+value grid cell.
 * @param {string} label
 * @param {string} value
 * @param {boolean} raw   — if true, value is already HTML (don't escape)
 */
function detailField(label, value, raw) {
  const display = raw ? (value || '—') : esc(value || '—');
  return '<div class="detail-field">' +
    '<label>' + esc(label) + '</label>' +
    '<span>' + display + '</span>' +
    '</div>';
}
