/**
 * reminders.js — Reminder generation panel for Aarogya Path Karnataka
 *
 * Features:
 *   - Consent checkbox (must be checked before generating)
 *   - Language toggle: translate text to English / Kannada
 *   - "Generate Reminder" button (disabled until consent checked)
 *   - Displays both English and Kannada reminder text
 *
 * Injected into the referral detail panel via showReminderSection().
 */

/**
 * showReminderSection — Inject the reminder form into the referral detail panel.
 * Called by the "Generate Reminder" button in dashboard.js.
 *
 * @param {number} referralId
 */
function showReminderSection(referralId) {
  const panel = document.getElementById('reminder-panel-' + referralId);
  if (!panel) return;

  panel.innerHTML = `
    <div style="border-top:1px solid #e5e7eb;padding-top:1rem;margin-top:0.5rem;">
      <h3>Generate Patient Reminder</h3>
      <p style="font-size:0.85rem;color:#57606a;margin-bottom:0.8rem;">
        A reminder will be generated in English and translated to Kannada using
        IBM Granite. Patient consent is required.
      </p>

      <div id="reminderAlert-${referralId}"></div>

      <label style="display:flex;align-items:flex-start;gap:0.5rem;cursor:pointer;margin-bottom:0.9rem;">
        <input
          type="checkbox"
          id="consentCheck-${referralId}"
          onchange="toggleReminderBtn(${referralId})"
          style="margin-top:0.3rem;width:auto;"
        />
        <span style="font-size:0.88rem;">
          I confirm the patient has given verbal consent for this reminder
          message to be generated and stored.
        </span>
      </label>

      <div class="flex gap-1 align-center" style="flex-wrap:wrap;margin-bottom:0.8rem;">
        <button
          class="btn btn-primary btn-sm"
          id="genReminderBtn-${referralId}"
          disabled
          onclick="generateReminderForReferral(${referralId})"
        >Generate Reminder</button>

        <button
          class="btn btn-secondary btn-sm"
          id="translateEnBtn-${referralId}"
          style="display:none;"
          onclick="translateReminder(${referralId}, 'en')"
        >Translate to English</button>

        <button
          class="btn btn-secondary btn-sm"
          id="translateKnBtn-${referralId}"
          style="display:none;"
          onclick="translateReminder(${referralId}, 'kn')"
        >Translate to Kannada (ಕನ್ನಡ)</button>
      </div>

      <div id="reminderOutput-${referralId}"></div>
    </div>
  `;
}

/**
 * toggleReminderBtn — Enable/disable the Generate Reminder button based on consent.
 */
function toggleReminderBtn(referralId) {
  const checkbox = document.getElementById('consentCheck-' + referralId);
  const btn      = document.getElementById('genReminderBtn-' + referralId);
  if (checkbox && btn) {
    btn.disabled = !checkbox.checked;
  }
}

/**
 * generateReminderForReferral — POST to /api/referral/{id}/reminder.
 * Displays both English and Kannada reminder text.
 */
async function generateReminderForReferral(referralId) {
  const alertBox = document.getElementById('reminderAlert-' + referralId);
  const output   = document.getElementById('reminderOutput-' + referralId);
  const btn      = document.getElementById('genReminderBtn-' + referralId);

  const consent = document.getElementById('consentCheck-' + referralId);
  if (!consent || !consent.checked) {
    alertBox.innerHTML = '<div class="alert alert-warn">Please confirm patient consent first.</div>';
    return;
  }

  alertBox.innerHTML = '';
  btn.disabled = true;
  btn.textContent = 'Generating...';
  output.innerHTML = '<span class="loading"></span> Generating reminder and translating to Kannada...';

  const data = await apiFetch('/api/referral/' + referralId + '/reminder', {
    method: 'POST',
    body: JSON.stringify({ consent_given: true })
  });

  btn.disabled = false;
  btn.textContent = 'Regenerate Reminder';

  if (!data || !data.success) {
    output.innerHTML = '';
    alertBox.innerHTML = '<div class="alert alert-error">Failed to generate reminder: ' +
      esc((data && data.error) || 'Unknown error') + '</div>';
    return;
  }

  const msgEn = data.data.message_en || '';
  const msgKn = data.data.message_kn || '';

  // Show language toggle buttons
  document.getElementById('translateEnBtn-' + referralId).style.display = 'inline-block';
  document.getElementById('translateKnBtn-' + referralId).style.display = 'inline-block';

  // Render both versions
  output.innerHTML =
    '<div style="margin-bottom:0.8rem;">' +
    '<div style="font-size:0.75rem;text-transform:uppercase;letter-spacing:0.05em;color:#57606a;margin-bottom:0.3rem;">English</div>' +
    '<div style="background:#f7f9fc;border:1px solid #dbe8f4;border-radius:6px;padding:0.8rem;font-size:0.9rem;">' +
    esc(msgEn) +
    '</div></div>' +
    '<div>' +
    '<div style="font-size:0.75rem;text-transform:uppercase;letter-spacing:0.05em;color:#57606a;margin-bottom:0.3rem;">Kannada (ಕನ್ನಡ)</div>' +
    '<div class="kn-text" style="background:#f7f9fc;border:1px solid #dbe8f4;border-radius:6px;padding:0.8rem;">' +
    esc(msgKn) +
    '</div></div>';

  // Store reminder data on the element for the translate function
  output.dataset.msgEn = msgEn;
  output.dataset.msgKn = msgKn;
}

/**
 * translateReminder — Translate custom text using the translate API.
 * Shows a text field where staff can type text to translate.
 *
 * @param {number} referralId
 * @param {string} lang — 'en' or 'kn'
 */
async function translateReminder(referralId, lang) {
  const alertBox = document.getElementById('reminderAlert-' + referralId);
  alertBox.innerHTML = '';

  const text = prompt(
    'Enter text to translate to ' + (lang === 'kn' ? 'Kannada (ಕನ್ನಡ)' : 'English') + ':',
    ''
  );

  if (!text || !text.trim()) return;

  const data = await apiFetch('/api/referral/' + referralId + '/translate', {
    method: 'POST',
    body: JSON.stringify({ text: text.trim(), target_language: lang })
  });

  if (!data || !data.success) {
    alertBox.innerHTML = '<div class="alert alert-error">Translation failed: ' +
      esc((data && data.error) || '') + '</div>';
    return;
  }

  const translated = data.data.translated_text || '';
  const langLabel  = lang === 'kn' ? 'Kannada (ಕನ್ನಡ)' : 'English';

  alertBox.innerHTML =
    '<div class="alert alert-success">' +
    '<strong>Translation to ' + esc(langLabel) + ':</strong><br>' +
    '<span class="' + (lang === 'kn' ? 'kn-text' : '') + '">' +
    esc(translated) + '</span>' +
    '</div>';
}
