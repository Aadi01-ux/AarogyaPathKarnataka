/**
 * referral.js — Upload Referral tab for Aarogya Path Karnataka
 *
 * Features:
 *   - Patient dropdown populated from /api/patients
 *   - Textarea for document text with live character counter (max 5000)
 *   - Submit → POST /api/referral/upload → show extracted data
 *   - "Build Care Journey" button after successful upload
 */

/** Current referral ID after a successful upload. */
let _uploadedReferralId = null;

/**
 * loadReferralForm — Build and inject the upload form into #tab-upload.
 * Called by index.html when the Upload Referral tab is activated.
 */
async function loadReferralForm() {
  const container = document.getElementById('tab-upload');
  if (!container) return;

  // Fetch patients for the dropdown
  const pData = await apiFetch('/api/patients');
  const patients = (pData && pData.success && pData.data.patients) ? pData.data.patients : [];

  let patientOptions = '<option value="">— Select patient —</option>';
  patients.forEach(p => {
    patientOptions += '<option value="' + p.id + '">' +
      esc(p.name) + ' (' + esc(p.village || 'unknown') + ')' +
      '</option>';
  });

  container.innerHTML = `
    <div class="card">
      <h2>Upload Referral Document</h2>
      <p class="text-muted" style="font-size:0.88rem;margin-bottom:1rem;">
        Paste the text from a referral document. IBM Granite will extract the
        key fields automatically. (Synthetic data only.)
      </p>

      <div id="uploadAlert"></div>

      <form id="uploadForm" novalidate>
        <div class="form-group">
          <label for="patientSelect">Patient</label>
          <select id="patientSelect" required>
            ${patientOptions}
          </select>
        </div>

        <div class="form-group">
          <label for="docText">Referral Document Text</label>
          <textarea
            id="docText"
            placeholder="Paste referral document text here (max 5000 characters)..."
            maxlength="5000"
            rows="8"
          ></textarea>
          <div class="char-counter" id="charCounter">0 / 5000</div>
        </div>

        <button type="submit" class="btn btn-primary" id="uploadBtn">
          Extract Referral with IBM Granite
        </button>
      </form>
    </div>

    <!-- Results panel — shown after successful upload -->
    <div id="extractedPanel" style="display:none;" class="card">
      <h2>Extracted Referral Data</h2>
      <div id="extractedContent"></div>
      <div style="margin-top:1rem;" class="flex gap-1">
        <button class="btn btn-primary" id="journeyBtn" style="display:none;"
          onclick="buildJourneyFromUpload()">Build Care Journey</button>
      </div>
      <div id="journeyResult" style="margin-top:1rem;"></div>
    </div>
  `;

  // --- Character counter ---
  const textarea = document.getElementById('docText');
  const counter  = document.getElementById('charCounter');
  textarea.addEventListener('input', () => {
    const len = textarea.value.length;
    counter.textContent = len + ' / 5000';
    counter.classList.toggle('over-limit', len > 5000);
  });

  // --- Form submit ---
  document.getElementById('uploadForm').addEventListener('submit', handleUploadSubmit);
}

/**
 * handleUploadSubmit — POST to /api/referral/upload and render results.
 */
async function handleUploadSubmit(e) {
  e.preventDefault();
  _uploadedReferralId = null;

  const alertBox   = document.getElementById('uploadAlert');
  const patientId  = document.getElementById('patientSelect').value;
  const docText    = document.getElementById('docText').value.trim();
  const btn        = document.getElementById('uploadBtn');

  alertBox.innerHTML = '';

  if (!patientId) {
    alertBox.innerHTML = '<div class="alert alert-error">Please select a patient.</div>';
    return;
  }
  if (!docText) {
    alertBox.innerHTML = '<div class="alert alert-error">Please paste referral document text.</div>';
    return;
  }
  if (docText.length > 5000) {
    alertBox.innerHTML = '<div class="alert alert-error">Document text exceeds 5000 characters.</div>';
    return;
  }

  btn.disabled = true;
  btn.textContent = 'Processing with IBM Granite...';

  const data = await apiFetch('/api/referral/upload', {
    method: 'POST',
    body: JSON.stringify({ patient_id: parseInt(patientId), document_text: docText })
  });

  btn.disabled = false;
  btn.textContent = 'Extract Referral with IBM Granite';

  if (!data || !data.success) {
    alertBox.innerHTML = '<div class="alert alert-error">Upload failed: ' +
      esc((data && data.error) || 'Unknown error') + '</div>';
    return;
  }

  // Show success
  alertBox.innerHTML = '<div class="alert alert-success">Referral extracted successfully!</div>';

  const extracted   = data.data.extracted || {};
  _uploadedReferralId = data.data.referral_id;

  // Render extracted fields
  const content = document.getElementById('extractedContent');
  content.innerHTML =
    '<div class="detail-grid">' +
    detailField('Referring Doctor', extracted.referring_doctor) +
    detailField('Specialist Needed', extracted.specialist_needed) +
    detailField('Urgency', extracted.urgency
      ? '<span class="' + urgencyClass(extracted.urgency) + '">' + esc(extracted.urgency) + '</span>'
      : '—', true) +
    detailField('Notes', extracted.notes || extracted.raw || '—') +
    '</div>' +
    (extracted.parse_error
      ? '<div class="alert alert-warn">AI response could not be fully parsed. Raw response stored.</div>'
      : '');

  document.getElementById('extractedPanel').style.display = 'block';
  document.getElementById('journeyBtn').style.display = 'inline-block';
  document.getElementById('journeyResult').innerHTML = '';
}

/**
 * buildJourneyFromUpload — Request a care journey for the last uploaded referral.
 */
async function buildJourneyFromUpload() {
  if (!_uploadedReferralId) return;

  const btn = document.getElementById('journeyBtn');
  const result = document.getElementById('journeyResult');

  btn.disabled = true;
  btn.textContent = 'Generating journey...';
  result.innerHTML = '<span class="loading"></span> Calling IBM Granite for care steps...';

  const data = await apiFetch('/api/referral/' + _uploadedReferralId + '/journey');
  btn.disabled = false;
  btn.textContent = 'Rebuild Journey';

  if (!data || !data.success) {
    result.innerHTML = '<div class="alert alert-error">Journey generation failed: ' +
      esc((data && data.error) || '') + '</div>';
    return;
  }

  const steps = (data.data && data.data.steps) || [];
  if (steps.length === 0) {
    result.innerHTML = '<div class="alert alert-info">No steps returned from AI.</div>';
    return;
  }

  let html = '<h3>Care Journey Steps</h3><ul class="timeline">';
  steps.forEach(s => {
    html += '<li>' +
      '<span class="timeline-step">Step ' + esc(String(s.step_number)) + '</span>' +
      '<div>' +
      '<div class="timeline-desc">' + esc(s.description) + '</div>' +
      '<div class="timeline-loc">' + esc(s.location) + ' &bull; ' + esc(s.type) + '</div>' +
      '</div></li>';
  });
  html += '</ul>';
  result.innerHTML = html;
}
