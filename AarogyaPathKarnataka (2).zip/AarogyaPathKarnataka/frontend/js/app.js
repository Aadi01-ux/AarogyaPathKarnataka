/**
 * app.js — Shared utilities for Aarogya Path Karnataka frontend
 *
 * Provides:
 *   apiFetch(path, options) — authenticated fetch with 401 redirect
 *   checkAuth()             — verify session, redirect to /login if not logged in
 *   loadPatients()          — populate the Patients tab
 *   badge(status)           — returns HTML for a status badge
 *   urgencyClass(u)         — returns CSS class for urgency level
 */

const API_BASE = 'http://127.0.0.1:5000';

/** Current logged-in staff user. Set by checkAuth() on page load. */
let _currentUser = null;

/**
 * apiFetch — Wrapper around fetch() that:
 *   1. Prepends API_BASE to the path
 *   2. Includes session cookies (credentials: 'include')
 *   3. Sets Content-Type: application/json for POST/PUT
 *   4. On 401 response, redirects to /login automatically
 *
 * @param {string} path     - API path, e.g. '/api/dashboard'
 * @param {object} options  - fetch options (method, body, etc.)
 * @returns {Promise<object>} Parsed JSON response
 */
async function apiFetch(path, options = {}) {
  const defaults = {
    credentials: 'include',
    headers: { 'Content-Type': 'application/json' }
  };

  // Merge headers
  const fetchOptions = {
    ...defaults,
    ...options,
    headers: { ...defaults.headers, ...(options.headers || {}) }
  };

  const response = await fetch(API_BASE + path, fetchOptions);

  // If the session expired or the user is not logged in, go to login page
  if (response.status === 401) {
    window.location.href = '/login';
    return null;
  }

  return response.json();
}

/**
 * checkAuth — Called on page load to verify the user has a valid session.
 * Redirects to /login if not authenticated.
 *
 * @returns {Promise<object|null>} User data object, or null if redirect happened
 */
async function checkAuth() {
  try {
    const data = await apiFetch('/api/auth/me');
    if (!data || !data.success) {
      window.location.href = '/login';
      return null;
    }
    _currentUser = data.data;
    return data.data;
  } catch (err) {
    // Network error — server probably not running
    document.body.innerHTML =
      '<div style="text-align:center;padding:3rem;">' +
      '<h2 style="color:#b91c1c;">Cannot connect to server</h2>' +
      '<p>Make sure the Flask backend is running: <code>python backend/app.py</code></p>' +
      '</div>';
    return null;
  }
}

/**
 * loadPatients — Fetch and render the patients list.
 * Called when the Patients tab is activated.
 * Shows "Add Patient" form for admin users only.
 */
async function loadPatients() {
  const container = document.getElementById('patientsContent');
  if (!container) return;

  container.innerHTML = '<span class="loading"></span> Loading patients...';

  const data = await apiFetch('/api/patients');
  if (!data || !data.success) {
    container.innerHTML = '<div class="alert alert-error">Failed to load patients.</div>';
    return;
  }

  const patients = data.data.patients || [];
  const isAdmin  = _currentUser && _currentUser.role === 'admin';

  let html = '';

  // --- Add Patient form (admin only) ---
  if (isAdmin) {
    html += `
      <div class="card" style="margin-bottom:1.2rem;">
        <h3 style="margin-bottom:0.9rem;">Add New Patient</h3>
        <div id="addPatientAlert"></div>
        <form id="addPatientForm" novalidate>
          <div class="form-group">
            <label for="newPatientName">Full Name <span style="color:#b91c1c;">*</span></label>
            <input type="text" id="newPatientName" placeholder="e.g. Ravi Kumar" required />
          </div>
          <div style="display:flex;gap:0.8rem;flex-wrap:wrap;">
            <div class="form-group" style="flex:1;min-width:140px;">
              <label for="newPatientVillage">Village / Taluk</label>
              <input type="text" id="newPatientVillage" placeholder="e.g. Hesaraghatta" />
            </div>
            <div class="form-group" style="flex:1;min-width:140px;">
              <label for="newPatientPhone">Mobile Number</label>
              <input type="tel" id="newPatientPhone" placeholder="e.g. +91-9876500011" />
            </div>
          </div>
          <div style="display:flex;gap:0.8rem;flex-wrap:wrap;align-items:flex-end;">
            <div class="form-group" style="flex:1;min-width:140px;">
              <label for="newPatientLang">Language Preference</label>
              <select id="newPatientLang">
                <option value="en">English</option>
                <option value="kn">Kannada (ಕನ್ನಡ)</option>
              </select>
            </div>
            <div class="form-group" style="flex:1;min-width:140px;padding-bottom:0.1rem;">
              <label style="display:flex;align-items:center;gap:0.5rem;cursor:pointer;">
                <input type="checkbox" id="newPatientConsent" style="width:auto;" />
                Consent on file
              </label>
            </div>
          </div>
          <button type="submit" class="btn btn-primary" id="addPatientBtn" style="margin-top:0.3rem;">
            Add Patient
          </button>
        </form>
      </div>`;
  }

  // --- Patients table ---
  if (patients.length === 0) {
    html += '<div class="alert alert-info">No patients found. Run seed data first.</div>';
  } else {
    html += '<table class="data-table"><thead><tr>' +
      '<th>Name</th><th>Village</th><th>Phone</th>' +
      '<th>Language</th><th>Consent</th>' +
      '</tr></thead><tbody>';

    patients.forEach(p => {
      html += '<tr>' +
        '<td>' + esc(p.name) + '</td>' +
        '<td>' + esc(p.village || '—') + '</td>' +
        '<td>' + esc(p.phone || '—') + '</td>' +
        '<td>' + (p.language_pref === 'kn' ? 'Kannada (ಕನ್ನಡ)' : 'English') + '</td>' +
        '<td>' + (p.consent_on_file
          ? '<span class="badge badge-completed">Yes</span>'
          : '<span class="badge badge-unconfirmed">No</span>') +
        '</td>' +
        '</tr>';
    });

    html += '</tbody></table>';
  }

  container.innerHTML = html;

  // Attach form handler after innerHTML is set
  if (isAdmin) {
    document.getElementById('addPatientForm').addEventListener('submit', handleAddPatient);
  }
}

/**
 * handleAddPatient — POST to /api/patients and refresh the patients list on success.
 */
async function handleAddPatient(e) {
  e.preventDefault();
  const alertBox = document.getElementById('addPatientAlert');
  const btn      = document.getElementById('addPatientBtn');

  const name    = document.getElementById('newPatientName').value.trim();
  const village = document.getElementById('newPatientVillage').value.trim();
  const phone   = document.getElementById('newPatientPhone').value.trim();
  const lang    = document.getElementById('newPatientLang').value;
  const consent = document.getElementById('newPatientConsent').checked;

  alertBox.innerHTML = '';

  if (!name) {
    alertBox.innerHTML = '<div class="alert alert-error">Patient name is required.</div>';
    return;
  }

  btn.disabled = true;
  btn.textContent = 'Adding...';

  const data = await apiFetch('/api/patients', {
    method: 'POST',
    body: JSON.stringify({
      name,
      village:         village || null,
      phone:           phone   || null,
      language_pref:   lang,
      consent_on_file: consent
    })
  });

  btn.disabled = false;
  btn.textContent = 'Add Patient';

  if (!data || !data.success) {
    alertBox.innerHTML = '<div class="alert alert-error">' +
      esc((data && data.error) || 'Failed to add patient.') + '</div>';
    return;
  }

  alertBox.innerHTML = '<div class="alert alert-success">Patient "' +
    esc(data.data.patient.name) + '" added successfully!</div>';

  // Clear the form fields
  document.getElementById('addPatientForm').reset();

  // Refresh the patient table (reload full list from server)
  setTimeout(loadPatients, 800);
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/**
 * badge — Return HTML for a coloured status badge.
 * @param {string} status
 * @returns {string} HTML string
 */
function badge(status) {
  const cls = {
    pending:     'badge-pending',
    confirmed:   'badge-confirmed',
    completed:   'badge-completed',
    unconfirmed: 'badge-unconfirmed'
  }[status] || 'badge-unconfirmed';
  return '<span class="badge ' + cls + '">' + esc(status) + '</span>';
}

/**
 * urgencyClass — Return CSS class for an urgency level.
 * @param {string} u
 * @returns {string}
 */
function urgencyClass(u) {
  return { high: 'urgency-high', medium: 'urgency-medium', low: 'urgency-low' }[u] || '';
}

/**
 * esc — HTML-escape a string to prevent XSS.
 * @param {*} s
 * @returns {string}
 */
function esc(s) {
  if (s == null) return '';
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

/**
 * formatDate — Format an ISO date string for display.
 * @param {string} iso
 * @returns {string}
 */
function formatDate(iso) {
  if (!iso) return '—';
  try {
    return new Date(iso).toLocaleDateString('en-IN', {
      day: '2-digit', month: 'short', year: 'numeric'
    });
  } catch (e) {
    return iso;
  }
}
