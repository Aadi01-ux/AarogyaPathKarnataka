# Aarogya Path Karnataka 🏥

**Rural Healthcare Referral & Follow-up Coordination System**  
IBM Bob Hackathon — Multi-Agent AI with Dual Portal (Staff + Patient)

A multi-agent AI system that simplifies healthcare coordination for rural patients in Karnataka — covering specialist referrals, lab tests, hospital visits, multilingual instructions (English & ಕನ್ನಡ), appointment reminders, and real-time status tracking.

---

## Features

### Staff Portal (`/login`)
- Secure staff login (admin / coordinator roles)
- Upload referral documents → IBM Granite extracts fields automatically
- Build AI-powered care journey plans
- Generate bilingual reminders (English + Kannada)
- Translate instructions using IBM Granite
- Add and manage patient records (admin only)
- Dashboard with referral stats and status tracking

### Patient Portal (`/patient-login`) — Mobile-First
- Patient self-registration (matched by phone number)
- View personal referrals and status
- View upcoming appointments and lab tests
- Read reminders and follow-up instructions
- Switch between English and Kannada (ಕನ್ನಡ)

---

## Architecture

```
Browser
├── Staff Portal    →  /login          (index.html, login.html)
└── Patient Portal  →  /patient-login  (patient-portal.html, patient-login.html)
        ↕  HTTPS + session cookies
Flask Backend (Python 3.12)
├── auth.py               — login_required + patient_login_required decorators
├── orchestrator.py       — central agent dispatch
├── routes/
│   ├── auth_routes.py         — staff auth
│   ├── api_routes.py          — staff API (16 endpoints)
│   ├── patient_auth_routes.py — patient auth
│   └── patient_routes.py      — patient API (read-only, ownership-enforced)
└── agents/
    ├── referral_processing_agent.py  — extracts fields via IBM Granite
    ├── care_journey_agent.py         — builds step plan via IBM Granite
    ├── status_tracking_agent.py      — DB reads, no AI
    ├── multilingual_agent.py         — EN ↔ ಕನ್ನಡ translation
    ├── reminder_agent.py             — bilingual reminder generation
    └── dashboard_agent.py            — aggregated stats
        ↕  REST API (IAM token auth)
IBM Granite (ibm/granite-13b-instruct-v2) on watsonx.ai
        ↕  SQLAlchemy ORM + PyMySQL
MySQL — aarogya_path database (8 tables)
```

---

## Prerequisites

- **Python 3.9+** — [python.org/downloads](https://www.python.org/downloads/)
- **MySQL 8.0+** — [mysql.com](https://dev.mysql.com/downloads/) or [XAMPP](https://www.apachefriends.org/)
- **IBM watsonx.ai account** — [ibm.com/watsonx](https://www.ibm.com/watsonx)
- A terminal (PowerShell, Command Prompt, or macOS/Linux shell)

---

## Setup Instructions

### 1. Clone the repository

```bash
git clone https://github.com/your-username/AarogyaPathKarnataka.git
cd AarogyaPathKarnataka
```

### 2. Create and activate a virtual environment

```bash
# Windows
python -m venv venv
venv\Scripts\activate

# macOS / Linux
python3 -m venv venv
source venv/bin/activate
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

### 4. Configure environment variables

```bash
# Windows
copy .env.example .env

# macOS / Linux
cp .env.example .env
```

Edit `.env` with your credentials:

```env
WATSONX_API_KEY=your_actual_api_key
WATSONX_PROJECT_ID=your_actual_project_id
WATSONX_URL=https://us-south.ml.cloud.ibm.com
WATSONX_MODEL_ID=ibm/granite-13b-instruct-v2
DB_HOST=localhost
DB_PORT=3306
DB_USER=your_mysql_username
DB_PASSWORD=your_mysql_password
DB_NAME=aarogya_path
SECRET_KEY=pick-a-long-random-string-here
```

> ⚠️ `.env` is in `.gitignore` and will never be committed.

### 5. Create the MySQL database and tables

Log in to MySQL and create the database:

```sql
CREATE DATABASE IF NOT EXISTS aarogya_path;
```

Then create all tables using Python (recommended — reads `.env` automatically):

```bash
python -c "
import sys; sys.path.insert(0,'backend')
from config import get_db_engine
from models.db_models import Base
Base.metadata.create_all(get_db_engine())
print('All tables created.')
"
```

### 6. Load synthetic seed data

```bash
python -c "import sys; sys.path.insert(0,'backend'); import seed_data; seed_data.main()"
```

### 7. Run the application

```bash
python backend/app.py
```

Expected output:
```
Starting Aarogya Path Karnataka backend...
Health check: http://127.0.0.1:5000/api/health
 * Running on http://0.0.0.0:5000
```

### 8. Open in browser

| Portal | URL |
|---|---|
| Staff Login | http://127.0.0.1:5000/login |
| Staff Dashboard | http://127.0.0.1:5000/ |
| Patient Login / Register | http://127.0.0.1:5000/patient-login |
| Patient Portal | http://127.0.0.1:5000/patient-portal |
| Health Check | http://127.0.0.1:5000/api/health |

---

## Demo Credentials

### Staff (pre-seeded)

| Username | Password | Role |
|---|---|---|
| `admin` | `Admin@1234` | admin |
| `coordinator` | `Coord@1234` | coordinator |

### Patient (register yourself)
1. Go to `/patient-login` → **Register** tab
2. Enter one of the seeded phone numbers (e.g. `+91-9876500001` for Ravi Kumar)
3. Choose a username and password → log in

---

## Project Structure

```
AarogyaPathKarnataka/
├── backend/
│   ├── app.py                    ← Flask entry point + page routes
│   ├── config.py                 ← Environment variables + DB helpers
│   ├── auth.py                   ← login_required + patient_login_required
│   ├── orchestrator.py           ← Central agent dispatch
│   ├── watsonx_client.py         ← IBM Granite REST client (IAM token cache)
│   ├── utils.py                  ← translate() + parse_json_from_response()
│   ├── seed_data.py              ← Synthetic data loader (idempotent)
│   ├── create_tables.sql         ← MySQL schema (original 7 tables)
│   ├── add_patient_users.sql     ← Migration: adds patient_users table
│   ├── agents/
│   │   ├── referral_processing_agent.py
│   │   ├── care_journey_agent.py
│   │   ├── status_tracking_agent.py
│   │   ├── multilingual_agent.py
│   │   ├── reminder_agent.py
│   │   └── dashboard_agent.py
│   ├── models/
│   │   └── db_models.py          ← SQLAlchemy ORM (8 models)
│   └── routes/
│       ├── api_routes.py         ← Staff API endpoints
│       ├── auth_routes.py        ← Staff authentication
│       ├── patient_routes.py     ← Patient API endpoints (read-only)
│       └── patient_auth_routes.py← Patient authentication
├── frontend/
│   ├── index.html                ← Staff dashboard shell
│   ├── login.html                ← Staff login
│   ├── patient-login.html        ← Patient login + registration
│   ├── patient-portal.html       ← Patient portal (mobile-first)
│   ├── css/
│   │   ├── style.css             ← Staff portal styles
│   │   └── patient-portal.css    ← Patient portal styles (mobile-first)
│   └── js/
│       ├── app.js                ← Shared staff utilities + auth guard
│       ├── dashboard.js          ← Dashboard + referral detail
│       ├── referral.js           ← Upload referral form
│       ├── reminders.js          ← Reminder generation panel
│       └── patient-app.js        ← Patient portal logic + i18n
├── .env.example                  ← Credential template
├── .gitignore
├── requirements.txt
└── README.md
```

---

## Privacy & Safety

- **No real patient data** — all records are synthetic (demo only)
- **No clinical decisions** — the system coordinates logistics only
- **Consent gate** — reminders require both staff confirmation and `consent_on_file = true`
- **Record isolation** — patients can only access their own records (session-enforced)
- **Role-based access** — only admin users can add new patients

---

## Tech Stack

| Layer | Technology |
|---|---|
| AI Model | IBM Granite (`ibm/granite-13b-instruct-v2`) via watsonx.ai |
| Backend | Python 3.12, Flask 3, SQLAlchemy, PyMySQL, bcrypt |
| Frontend | Vanilla HTML/CSS/JavaScript (no framework) |
| Database | MySQL 8 |
| Auth | Flask server-side sessions (signed cookies) |
